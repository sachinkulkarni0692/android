package com.example.sachi.inclass05;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView desc;
    TextView published;
    TextView headline;
    TextView description;
    TextView published_on;
    ImageView image;
    Button quit;

    TextView load;
    ProgressBar progressBar;

    static ArrayList<PaperData> articleList = new ArrayList<>();
    static int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        headline = findViewById(R.id.textView);
        description = findViewById(R.id.textView5);
        published_on = findViewById(R.id.textView3);
        image = findViewById(R.id.imageView2);
        load = findViewById(R.id.textView6);

        desc = findViewById(R.id.textView2);
        published = findViewById(R.id.textView4);
        progressBar = findViewById(R.id.progressBar);

        quit = (Button) findViewById(R.id.button);
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                finish();
                System.exit(0);
            }});

        if(isConnected()){
            progressBar.setVisibility(View.VISIBLE);
            load.setVisibility(View.VISIBLE);
            headline.setVisibility(View.INVISIBLE);
            description.setVisibility(View.INVISIBLE);
            published_on.setVisibility(View.INVISIBLE);
            desc.setVisibility(View.INVISIBLE);
            published.setVisibility(View.INVISIBLE);
            image.setVisibility(View.INVISIBLE);
            new getApi().execute("https://newsapi.org/v2/top-headlines?sources=buzzfeed&apiKey=9090bbb799b64372b4ecaf14b3439da7");
        }
        }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkinfo = connectivityManager.getActiveNetworkInfo();

        if ((networkinfo == null) || !networkinfo.isConnected() ||
                ((networkinfo.getType() != connectivityManager.TYPE_WIFI) && (networkinfo.getType() != connectivityManager.TYPE_MOBILE))){
            return false;
        }
        return true;
    }

    public class getApi extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try{
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader
                            (connection.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        result.append(line);
                    }
                    return result.toString();

            }}
            catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        protected void onPostExecute(String res){
            JSONObject root = null;
            try {
                root = new JSONObject(res);
                JSONArray articles = root.getJSONArray("articles");
                for(int i =0; i<articles.length();i++){
                    JSONObject articleJson = articles.getJSONObject(i);
                    String title = articleJson.getString("title");
                    String description = articleJson.getString("description");
                    String publishedAt = articleJson.getString("publishedAt");
                    String articleurl = articleJson.getString("urlToImage");
                    PaperData article = new PaperData(title,description,publishedAt,articleurl);
                    articleList.add(article);
                    }
                } catch (JSONException e) {
                   e.printStackTrace();
                }

            PaperData data = articleList.get(i);
            headline.setText(data.getTitle());
            description.setText(data.getDescription());
            published_on.setText(data.getPublishedAt().substring(0,10));
            new DisplayImage().execute(data.getUrl());
            //Picasso.get().load(data.getUrl()).into(image);
        }
    }

    private class DisplayImage extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... strings) {
            StringBuilder stbuilder = new StringBuilder();
            URL url = null;
            try {
                url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                Bitmap bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                return bitmap;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap res) {
            ImageView next = findViewById(R.id.imageView3);
            ImageView previous = findViewById(R.id.imageView);
            final PaperData data = articleList.get(i);
            headline.setText(data.getTitle());
            description.setText(data.getDescription());
            published_on.setText(data.getPublishedAt().substring(0,10));

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(i!=0){
                        i-=1;
                    }
                    else {
                        i=0;
                    }
                    progressBar.setVisibility(View.VISIBLE);
                    load.setVisibility(View.VISIBLE);
                    headline.setVisibility(View.INVISIBLE);
                    description.setVisibility(View.INVISIBLE);
                    published_on.setVisibility(View.INVISIBLE);
                    desc.setVisibility(View.INVISIBLE);
                    published.setVisibility(View.INVISIBLE);
                    image.setVisibility(View.INVISIBLE);
                    PaperData data = articleList.get(i);
                    new DisplayImage().execute(data.getUrl());
                    }
                }
            );

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (i!=articleList.size()-1){
                        i+=1;
                    }
                    else{
                        i = articleList.size()-1;
                    }
                    progressBar.setVisibility(View.VISIBLE);
                    load.setVisibility(View.VISIBLE);
                    headline.setVisibility(View.INVISIBLE);
                    description.setVisibility(View.INVISIBLE);
                    published_on.setVisibility(View.INVISIBLE);
                    desc.setVisibility(View.INVISIBLE);
                    published.setVisibility(View.INVISIBLE);
                    image.setVisibility(View.INVISIBLE);
                    PaperData data = articleList.get(i);
                    new DisplayImage().execute(data.getUrl());
                    }
                }
            );

            if (res != null) {
                progressBar.setVisibility(View.INVISIBLE);
                load.setVisibility(View.INVISIBLE);
                headline.setVisibility(View.VISIBLE);
                description.setVisibility(View.VISIBLE);
                published_on.setVisibility(View.VISIBLE);
                desc.setVisibility(View.VISIBLE);
                published.setVisibility(View.VISIBLE);
                image.setVisibility(View.VISIBLE);
                image.setImageBitmap(res);
            }
        }
    }
}