package com.example.sachi.hw05;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.example.sachi.hw05.MainActivity.sourceMap;

public class Main2Activity extends AppCompatActivity  {

    ProgressBar progressBarnews ;
    TextView textViewnews ;
    ArrayList<News> articleList = new ArrayList<>();
    ListView listView;
    private static CustomListAdapter adapter;

    String newsName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        progressBarnews = findViewById(R.id.progressBarnews);
        textViewnews = findViewById(R.id.textViewnews);

        Bundle b = getIntent().getExtras();
        final String selectednews = (String) b.get("newsSelected");
        ArrayList<String> sources = getIntent().getStringArrayListExtra("sourceNames");
        newsName = sources.get(Integer.parseInt(selectednews));
        setTitle(newsName);

        Source source = sourceMap.get(newsName);
        String newsId = source.getId();

        progressBarnews.setVisibility(View.VISIBLE);
        textViewnews.setVisibility(View.VISIBLE);

        if(isConnected()){

            new Main2Activity.getApi().execute("https://newsapi.org/v2/top-headlines?sources="+newsId+"&apiKey=381eed50da0f410991811d391368eeba");
        }
    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkinfo = connectivityManager.getActiveNetworkInfo();

        if ((networkinfo == null) || !networkinfo.isConnected() ||
                ((networkinfo.getType() != connectivityManager.TYPE_WIFI) && (networkinfo.getType() != connectivityManager.TYPE_MOBILE))){
            return false;
        }
        return true;
    }

    public class getApi extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try{
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader
                            (connection.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        result.append(line);
                    }
                    return result.toString();

                }}
            catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        protected void onPostExecute(String res){
            JSONObject root = null;
            try {
                if (res.length()>0)
                {
                    root = new JSONObject(res);
                    JSONArray sources = root.getJSONArray("articles");
                    for(int i =0; i<sources.length();i++){
                        JSONObject sourceJson = sources.getJSONObject(i);
                        String author = sourceJson.getString("author");
                        String title = sourceJson.getString("title");
                        String url = sourceJson.getString("urlToImage");
                        String webUrl = sourceJson.getString("url");
                        String publishedAt = sourceJson.getString("publishedAt");
                        News article = new News(author, title, url, publishedAt,webUrl);
                        articleList.add(article);
                    }
                    listView=(ListView)findViewById(R.id.newsArticleList);
                    adapter = new CustomListAdapter(articleList,getApplicationContext());

                    for (int i =0;i<1000;i++){
                        for (int j=0 ;j<1000000;j++){}
                    }
                    listView.setAdapter(adapter);
                    progressBarnews.setVisibility(View.INVISIBLE);
                    textViewnews.setVisibility(View.INVISIBLE);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            News dataModel= articleList.get(position);
                            Intent intents = new Intent(Main2Activity.this,Main3Activity.class);
                            intents.putExtra("selectedNewsArticle",dataModel.getWebUrl());
                            intents.putExtra("title",newsName);
                            startActivity(intents);
                        }
                    });
                }
                else{
                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, "The url did not return any news information!!!", Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                    displayToast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
