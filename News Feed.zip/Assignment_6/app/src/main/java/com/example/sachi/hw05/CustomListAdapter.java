package com.example.sachi.hw05;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CustomListAdapter extends ArrayAdapter<News> implements View.OnClickListener{
    @Override
    public void onClick(View v) {

    }

    // View lookup cache
    private static class ViewHolder {

        ImageView articleUrl ;
        TextView articleTitle;
        TextView articleAuthor;
        TextView articleDate;
    }

     Context context;

    private ArrayList<News> articleList;

    public CustomListAdapter(ArrayList<News> articleList,Context context) {
        super(context, R.layout.customlist, articleList);
        // TODO Auto-generated constructor stub
        this.context=context;
        this.articleList=articleList;
    }

   /* @Override
    public void onClick(View v) {


        int position=(Integer) v.getTag();
        Object object= getItem(position);
        News dataModel=(News)object;




        switch (v.getId())
        {

            case R.id.item_info:

                Snackbar.make(v, "Release date " +dataModel.getFeature(), Snackbar.LENGTH_LONG)
                        .setAction("No action", null).show();

                break;


        }


    }*/
    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        News dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.customlist, parent, false);

            viewHolder.articleUrl = (ImageView) convertView.findViewById(R.id.articleURL);
            viewHolder.articleTitle = (TextView) convertView.findViewById(R.id.articleTitle);
            viewHolder.articleAuthor = (TextView) convertView.findViewById(R.id.articleAuthor);
            viewHolder.articleDate = (TextView) convertView.findViewById(R.id.articleDate);

            result=convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        lastPosition = position;

        //viewHolder.articleUrl.setText(dataModel.getName());
        if(dataModel.getUrl().length()>0)// && dataModel.getTitle().length()>0 && dataModel.getAuthor().length()>0 && dataModel.getPublishedAt().length()>0)
        {
            Picasso.get().load(dataModel.getUrl()).into(viewHolder.articleUrl);
        }
        viewHolder.articleTitle.setText(dataModel.getTitle());
        viewHolder.articleAuthor.setText(dataModel.getAuthor());
        viewHolder.articleDate.setText(dataModel.getPublishedAt().substring(0,10));
        //viewHolder.articleAuthor.setOnClickListener(this);
        //viewHolder.articleDate.setTag(position);
        // Return the completed view to render on screen

        return convertView;
    }

}