package com.example.sachi.hw05;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView textView;
    final static HashMap<String,Source> sourceMap = new HashMap<>();
    static ArrayList<String> sourceNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = findViewById(R.id.progressBar);
        textView = findViewById(R.id.textView);
        sourceMap.clear();
        sourceNames.clear();

        if(isConnected()){
            progressBar.setVisibility(View.VISIBLE);
            textView.setVisibility(View.VISIBLE);
            new getApi().execute("https://newsapi.org/v2/sources?apiKey=381eed50da0f410991811d391368eeba");
        }
    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkinfo = connectivityManager.getActiveNetworkInfo();

        if ((networkinfo == null) || !networkinfo.isConnected() ||
                ((networkinfo.getType() != connectivityManager.TYPE_WIFI) && (networkinfo.getType() != connectivityManager.TYPE_MOBILE))){
            return false;
        }
        return true;
    }

    public class getApi extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try{
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader
                            (connection.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        result.append(line);
                    }
                    return result.toString();

                }}
            catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        protected void onPostExecute(String res){
            JSONObject root = null;
            try {
                root = new JSONObject(res);
                JSONArray sources = root.getJSONArray("sources");
                for(int i =0; i<sources.length();i++){
                    JSONObject sourceJson = sources.getJSONObject(i);
                    String id = sourceJson.getString("id");
                    String name = sourceJson.getString("name");
                    Source news_source = new Source(id, name);
                    sourceMap.put(name,news_source);
                    sourceNames.add(name);
                }

                List<String> keyList = new ArrayList<String>(sourceNames);
                final ArrayAdapter<String> adp = new ArrayAdapter<String>(MainActivity.this,
                        android.R.layout.simple_list_item_1, keyList);
                final ListView sp = new ListView(MainActivity.this);
                sp.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                sp.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
                sp.setAdapter(adp);

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setView(sp);
                builder.create().show();
                progressBar.setVisibility(View.INVISIBLE);
                textView.setVisibility(View.INVISIBLE);
                sp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> listView, View itemView, int itemPosition, long itemId)
                    {
                        Intent intents = new Intent(MainActivity.this,Main2Activity.class);
                        intents.putExtra("newsSelected",String.valueOf(itemPosition));
                        intents.putStringArrayListExtra("sourceNames",sourceNames);
                        startActivity(intents);
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }

            //Picasso.get().load(data.getUrl()).into(image);
        }
    }

}
