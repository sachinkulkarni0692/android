package com.example.sachi.hw05;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    private WebView webView = null;
    ProgressBar progressBarnews ;
    TextView textViewnews ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        progressBarnews = findViewById(R.id.progressBarnews);
        textViewnews = findViewById(R.id.textViewnews);
        progressBarnews.setVisibility(View.VISIBLE); //test
        textViewnews.setVisibility(View.VISIBLE); // test

        Bundle b = getIntent().getExtras();
        setTitle((String) b.get("title"));
        final String webUrl = (String) b.get("selectedNewsArticle");
        webView = (WebView) findViewById(R.id.webview);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        WebViewClientImpl webViewClient = new WebViewClientImpl(this);
        webView.setWebViewClient(webViewClient);
        progressBarnews.setVisibility(View.INVISIBLE); //test
        textViewnews.setVisibility(View.INVISIBLE); // test
        webView.loadUrl(webUrl);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && this.webView.canGoBack()) {
            this.webView.goBack();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
}
