package com.example.sachi.hw05;

public class News {
    private String author;
    private String title;
    private String url;
    private String publishedAt;
    private String webUrl;

    public News(String author, String title, String url, String publishedAt, String webUrl){
        this.author = (author == null ? "": author);
        this.title = (title == null ? "" :title);
        this.url = (url == null ? "": url);
        this.publishedAt = (publishedAt == null ? "" : publishedAt);
        this.webUrl = (webUrl == null ? "" : webUrl);

    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public String getWebUrl() {
        return webUrl;
    }

    @Override
    public String toString() {
        return "News{" +
                "author='" + author + '\'' +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", publishedAt='" + publishedAt + '\'' +
                ", webUrl='" + webUrl + '\'' +
                '}';
    }
}
