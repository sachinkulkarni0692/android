package com.example.sachi.inclass03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {
    ImageView selectedAvatar;
    Button editBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.display_profile);
        setContentView(R.layout.activity_main3);

        selectedAvatar = findViewById(R.id.imageView9);
        Bundle b = getIntent().getExtras();
        editBtn = findViewById(R.id.button2);

        TextView name = findViewById(R.id.textView7);
        TextView stud = findViewById(R.id.textView8);
        TextView dep = findViewById(R.id.textView11);

        int img = b.getInt("avatarimage");
        String fname = b.getString("firstname");
        String lname = b.getString("lastname");
        String studid = b.getString("studid");
        String depId = b.getString("department");

        name.setText(fname + " "+ lname);
        stud.setText(studid);
        dep.setText(depId);

        selectedAvatar.setImageResource(img);

        editBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent backToHomeActivityIntent = new Intent(Main3Activity.this, MainActivity.class);
                backToHomeActivityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(backToHomeActivityIntent);
            }
        }
        );
    }
}
