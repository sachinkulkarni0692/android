package com.example.sachi.inclass03;

import android.content.Intent;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView selectAvatar;
    Button savebtn;
    EditText fname;
    EditText lname;
    EditText studId;
    String firstName;
    String lastName;
    String studentId;
    RadioGroup deptGrp;
    String selectedRadioBtnValue;
    String displayMsg;
    int img;

    boolean selecteddEP = false;
    int toastTime = Toast.LENGTH_LONG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        selectAvatar = findViewById(R.id.imageView);
        fname = findViewById(R.id.editText);
        lname = findViewById(R.id.editText2);
        studId = findViewById(R.id.editText3);
        deptGrp = findViewById(R.id.radioGroup2);
        selectAvatar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent  =  new Intent(MainActivity.this, Main2Activity.class);
                startActivityForResult(intent,2);
                }});

        savebtn = findViewById(R.id.button);

        deptGrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                RadioButton selectedRadioBtn = (RadioButton) group.findViewById(checkedId);
                selecteddEP = selectedRadioBtn.isChecked();
                selectedRadioBtnValue = String.valueOf(selectedRadioBtn.getText());
            }
        });

        savebtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                firstName = fname.getText().toString().trim();
                lastName = lname.getText().toString().trim();
                studentId = studId.getText().toString().trim();

                if (firstName.length() == 0 || lastName.length() ==0)
                {
                    Context appContext = getApplicationContext();
                    displayMsg = "Enter valid first name and Last Name";
                    Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 150, 700);
                    displayToast.show();
                }
                else if(studentId.equalsIgnoreCase("") || Integer.valueOf(studentId)<100000000)
                {
                    Context appContext = getApplicationContext();
                    displayMsg = "Enter valid 9 digit student ID";
                    Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 150, 700);
                    displayToast.show();
                }
                else if (!selecteddEP)
                {
                    Context appContext = getApplicationContext();
                    displayMsg = "Select a department";
                    Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 150, 700);
                    displayToast.show();
                }
                else
                {
                    Intent intent2 = new Intent(MainActivity.this, Main3Activity.class);
                    intent2.putExtra("avatarimage",img);
                    intent2.putExtra("firstname", firstName);
                    intent2.putExtra("lastname", lastName);
                    intent2.putExtra("studid", studentId);
                    intent2.putExtra("department", selectedRadioBtnValue);
                    startActivity(intent2);
                }
            }});

    }

    // Call Back method  to get the Message form other Activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==2)
        {
            Bundle b = data.getExtras();
            img = b.getInt("avatarimage");
            selectAvatar.setImageResource(img);
            TextView avatar = findViewById(R.id.textView5);
            avatar.setText("");
        }
    }
}