package com.example.sachi.inclass03;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.select_avatar);
        setContentView(R.layout.activity_main2);
        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setDisplayUseLogoEnabled(true);

        final ImageView avatar1 = findViewById(R.id.imageView2);
        final ImageView avatar2 = findViewById(R.id.imageView5);
        final ImageView avatar3 = findViewById(R.id.imageView7);
        final ImageView avatar4 = findViewById(R.id.imageView4);
        final ImageView avatar5 = findViewById(R.id.imageView6);
        final ImageView avatar6 = findViewById(R.id.imageView8);


        avatar1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent();
                intent1.putExtra("avatarimage",R.drawable.avatar_f_1);
                setResult(RESULT_OK, intent1);
                finish();//finishing activity
            }
        });

        avatar2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent();
                intent1.putExtra("avatarimage",R.drawable.avatar_f_2);
                setResult(RESULT_OK, intent1);
                finish();//finishing activity
            }
        });

        avatar3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent();
                intent1.putExtra("avatarimage",R.drawable.avatar_f_3);
                setResult(RESULT_OK, intent1);
                finish();//finishing activity
            }
        });

        avatar4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("avatarimage",R.drawable.avatar_m_1);
                setResult(RESULT_OK, intent);
                finish();//finishing activity
            }
        });

        avatar5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent();
                intent1.putExtra("avatarimage",R.drawable.avatar_m_2);
                setResult(RESULT_OK, intent1);
                finish();//finishing activity
            }
        });

        avatar6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                Intent intent1 = new Intent();
                intent1.putExtra("avatarimage",R.drawable.avatar_m_3);
                setResult(RESULT_OK, intent1);
                finish();//finishing activity
            }
        });

}}
