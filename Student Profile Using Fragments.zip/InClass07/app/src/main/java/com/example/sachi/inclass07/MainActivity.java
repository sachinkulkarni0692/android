package com.example.sachi.inclass07;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements editProfile.OnFragmentInteractionListener,
        selectImage.OnSelectImageFragmentInteractionListener,ShowData.OnShowDataFragmentInteractionListener{

    editProfile e = new editProfile();
    ShowData showData = new ShowData();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.container,e)
                .commit();
    }

    @Override
    public void gotoFragment() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container,new selectImage(),"second")
                .addToBackStack("e")
                .commit();
    }

    @Override
    public void selectImageFragment(int i) {
        Bundle data = new Bundle();//Use bundle to pass data
        data.putInt("data", i);//put string, int, etc in bundle with a key value
        e.setArguments(data);//Finally set argument bundle to fragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container,e,"third")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void goToDisplay(int img, String s, String s1, String s2, String s3) {
        Bundle data = new Bundle();//Use bundle to pass data
        data.putInt("avatarImage", img);
        data.putString("firstName",s);
        data.putString("lastName",s1);
        data.putString("studentId",s2);
        data.putString("selectedRadioBtnValue",s3);
        showData.setArguments(data);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container,showData,"fourth")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void showDataFragment() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container,e)
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }
}
