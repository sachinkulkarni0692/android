package com.example.sachi.inclass07;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class ShowData extends Fragment {
    private OnShowDataFragmentInteractionListener mListener;
    int img;
    String firstName;
    String lastName;
    String studentId;
    String selectedRadioBtnValue;

    public ShowData() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_show_data, container, false);
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            this.img = bundle.getInt("avatarImage",0);
            this.firstName = bundle.getString("firstName", "");
            this.lastName = bundle.getString("lastName", "");
            this.studentId = bundle.getString("studentId", "");
            this.selectedRadioBtnValue = bundle.getString("selectedRadioBtnValue", "");
        }
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ImageView selectedAvatar;
        Button editBtn;
        selectedAvatar = getActivity().findViewById(R.id.imageView9);
        editBtn = getActivity().findViewById(R.id.button2);

        TextView name = getActivity().findViewById(R.id.textView7);
        TextView stud = getActivity().findViewById(R.id.textView8);
        TextView dep = getActivity().findViewById(R.id.textView11);

        name.setText(firstName + " "+ lastName);
        stud.setText(studentId);
        dep.setText(selectedRadioBtnValue);
        selectedAvatar.setImageResource(img);

        editBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.showDataFragment();//img,firstName[0],lastName[0],studentId[0],selectedRadioBtnValue[0]);
                //Intent backToHomeActivityIntent = new Intent(Main3Activity.this, MainActivity.class);
                //backToHomeActivityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                //startActivity(backToHomeActivityIntent);
            }
        }
        );
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof selectImage.OnSelectImageFragmentInteractionListener) {
            mListener = (OnShowDataFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnShowDataFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnShowDataFragmentInteractionListener {
        // TODO: Update argument type and name
        void showDataFragment();
    }

}
