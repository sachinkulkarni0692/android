package com.example.sachi.inclass07;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class editProfile extends Fragment{
    boolean selecteddEP = false;
    int img =0;

    private OnFragmentInteractionListener mListener;

    public editProfile() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_edit_profile, container, false);
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            int myInt = bundle.getInt("data", 0);
            this.img=myInt;
        }
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final ImageView selectAvatar = getActivity(). findViewById(R.id.imageView);
        final EditText fname = getActivity().findViewById(R.id.editText);
        final EditText lname = getActivity().findViewById(R.id.editText2);
        final EditText studId = getActivity().findViewById(R.id.editText3);
        final RadioGroup deptGrp = getActivity().findViewById(R.id.radioGroup2);
        final String[] firstName = new String[1];
        final String[] lastName = new String[1];
        final String[] studentId = new String[1];
        final String[] displayMsg = new String[1];
        final String[] selectedRadioBtnValue = new String[1];

        if (img!=0){
            selectAvatar.setImageResource(img);
        }

        deptGrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                RadioButton selectedRadioBtn = (RadioButton) group.findViewById(checkedId);
                selecteddEP = selectedRadioBtn.isChecked();
                selectedRadioBtnValue[0] = String.valueOf(selectedRadioBtn.getText());
            }
        });

        selectAvatar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.gotoFragment();
            }
        });

        getActivity().findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstName[0] = fname.getText().toString().trim();
                lastName[0] = lname.getText().toString().trim();
                studentId[0] = studId.getText().toString().trim();

                if (firstName[0].length() == 0 || lastName[0].length() ==0)
                {
                    Context appContext = getActivity().getApplicationContext();
                    displayMsg[0] = "Enter valid first name and Last Name";
                    Toast displayToast = Toast.makeText(appContext, displayMsg[0], Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 150, 700);
                    displayToast.show();
                }
                else if(studentId[0].equalsIgnoreCase("") || Integer.valueOf(studentId[0])<100000000)
                {
                    Context appContext = getActivity().getApplicationContext();
                    displayMsg[0] = "Enter valid 9 digit student ID";
                    Toast displayToast = Toast.makeText(appContext, displayMsg[0], Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 150, 700);
                    displayToast.show();
                }
                else if (!selecteddEP)
                {
                    Context appContext = getActivity().getApplicationContext();
                    displayMsg[0] = "Select a department";
                    Toast displayToast = Toast.makeText(appContext, displayMsg[0], Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 150, 700);
                    displayToast.show();
                }
                else
                {
                    mListener.goToDisplay(img,firstName[0],lastName[0],studentId[0],selectedRadioBtnValue[0]);
                }
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void gotoFragment();
        void goToDisplay(int img, String s, String s1, String s2, String s3);
    }
}
