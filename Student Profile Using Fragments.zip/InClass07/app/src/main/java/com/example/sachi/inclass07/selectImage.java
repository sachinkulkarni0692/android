package com.example.sachi.inclass07;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import static android.app.Activity.RESULT_OK;


public class selectImage extends Fragment {
    private OnSelectImageFragmentInteractionListener mListener;

    public selectImage() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_select_image, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final ImageView avatar1 = getActivity().findViewById(R.id.imageView2);
        final ImageView avatar2 = getActivity().findViewById(R.id.imageView5);
        final ImageView avatar3 = getActivity().findViewById(R.id.imageView7);
        final ImageView avatar4 = getActivity().findViewById(R.id.imageView4);
        final ImageView avatar5 = getActivity().findViewById(R.id.imageView6);
        final ImageView avatar6 = getActivity().findViewById(R.id.imageView8);


        avatar1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.selectImageFragment(R.drawable.avatar_f_1);

            }
        });

        avatar2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.selectImageFragment(R.drawable.avatar_f_2);
            }
        });

        avatar3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.selectImageFragment(R.drawable.avatar_f_3);
            }
        });

        avatar4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.selectImageFragment(R.drawable.avatar_m_1);
            }
        });

        avatar5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mListener.selectImageFragment(R.drawable.avatar_m_2);
            }
        });

        avatar6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                mListener.selectImageFragment(R.drawable.avatar_m_3);
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnSelectImageFragmentInteractionListener) {
            mListener = (OnSelectImageFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnSelectImageFragmentInteractionListener {
        // TODO: Update argument type and name
        void selectImageFragment(int i);
    }
}
