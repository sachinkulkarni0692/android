package io.realm.todo;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.ocpsoft.prettytime.PrettyTime;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import io.realm.ObjectServerError;
import io.realm.Realm;
import io.realm.RealmResults;
import io.realm.Sort;
import io.realm.SyncConfiguration;
import io.realm.SyncCredentials;
import io.realm.SyncUser;
import io.realm.todo.model.Task;
import io.realm.todo.ui.ItemsRecyclerAdapter;

import static io.realm.todo.Constants.AUTH_URL;
import static io.realm.todo.Constants.REALM_BASE_URL;

public class WelcomeActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private EditText mNicknameTextView;
    private View mProgressView;
    private View mLoginFormView;
    private String priority;
    private Realm realm;
    private Button loginButton;
    private Spinner spinner;
    RecyclerView recyclerView;
    String priorityValue="High";
    String[] statusArray = new String[1];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        setTitle(R.string.title_activity_items);

        // Set up the login form.
        mNicknameTextView = findViewById(R.id.nickname);
        loginButton = findViewById(R.id.login_button);
        spinner =  findViewById(R.id.prioritySpinner);
        recyclerView = findViewById(R.id.recycler_view);

        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayList<String> categories = new ArrayList<>();
        categories.add("High");
        categories.add("Medium");
        categories.add("Low");

        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        spinner.setAdapter(dataAdapter);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mNicknameTextView.getText().toString().length() > 0) {
                    //priority = "High";
                    Log.d("text",mNicknameTextView.getText().toString());
                    statusArray[0]="All";
                    attemptLogin(mNicknameTextView.getText().toString(),statusArray);
                }
                else{
                    runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "Please enter a title!", Toast.LENGTH_LONG).show();
                    }
                });
                }
            }
        });
        mProgressView = findViewById(R.id.login_progress);
    }

    private void attemptLogin(String text,String... status) {
        // Reset errors.
        mNicknameTextView.setError(null);
        // Store values at the time of the login attempt.
        String nickname = "My Nickname";//;mNicknameTextView.getText().toString();
        showProgress(true);

        String stat = status[0];
        SyncCredentials credentials = SyncCredentials.nickname(nickname, false);
        SyncUser.logInAsync(credentials, AUTH_URL, new SyncUser.Callback<SyncUser>() {
            @Override
            public void onSuccess(SyncUser user) {
                showProgress(false);
                fetchDataFromDB(text,stat,false);
            }

            @Override
            public void onError(ObjectServerError error) {
                showProgress(false);
                mNicknameTextView.setError("Uh oh something went wrong! (check your logcat please)");
                mNicknameTextView.requestFocus();
                Log.e("Login error", error.toString());
            }
        });
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);
        mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
        mProgressView.animate().setDuration(shortAnimTime).alpha(
                show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            }
        });
        recyclerView.setVisibility(show ? View.GONE:View.VISIBLE);
        recyclerView.animate().setDuration(shortAnimTime).alpha(
                show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                recyclerView.setVisibility(show ? View.GONE:View.VISIBLE);
            }
        });
    }

    private void fetchDataFromDB(String text,String status,boolean flag){
        try {
            RealmResults<Task> items = setUpRealm(status);
            if(!flag){
                realm.executeTransactionAsync(realm -> {
                    Task task = new Task();
                    task.setTitle(text);
                    task.setStatus("Pending");
                    task.setPriority(priorityValue+" Priority");
                    PrettyTime p = new PrettyTime();
                    try {
                        Calendar cal = Calendar.getInstance();
                        Date createdTime = cal.getTime();
                        task.setTime(p.format(createdTime));
                    } catch (Exception e) {
                        task.setTime("");
                        e.printStackTrace();
                    }
                    realm.insert(task);
                });
            }

            final ItemsRecyclerAdapter itemsRecyclerAdapter = new ItemsRecyclerAdapter(items);

            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(itemsRecyclerAdapter);
            recyclerView.addOnItemTouchListener(new RecyclerViewTouchListener(getApplicationContext(), recyclerView, new RecyclerViewClickListener() {
                @Override
                public void onClick(View view, int position) {
                    //Toast.makeText(getApplicationContext(), bookList.get(position).getTitle() + " is clicked!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onLongClick(View view, int position) {
                    WelcomeActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                                    WelcomeActivity.this);

                            alertDialog2.setTitle("Confirm Delete...");

                            alertDialog2.setMessage("Are you sure you want delete this Task?");

                            alertDialog2.setPositiveButton("YES",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            int pos = position;
                                            String id = itemsRecyclerAdapter.getItem(pos).getItemId();
                                            realm.executeTransactionAsync(realm -> {
                                                Task item = realm.where(Task.class)
                                                        .equalTo("itemId", id)
                                                        .findFirst();
                                                if (item != null) {
                                                    item.deleteFromRealm();
                                                }
                                            });
                                            dialog.cancel();
                                        }
                                    });
                            alertDialog2.setNegativeButton("NO",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    });
                            alertDialog2.show();
                        }
                    });
                    //return true;
                }
            }));

            ItemTouchHelper.SimpleCallback simpleItemTouchCallback =
                    new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

                @Override
                public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                    return false;
                }

                @Override
                public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
                    WelcomeActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                                    WelcomeActivity.this);

                            alertDialog2.setTitle("Confirm Delete...");

                            alertDialog2.setMessage("Are you sure you want delete this Task?");

                            alertDialog2.setPositiveButton("YES",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            // Write your code here to execute after dialog
                                            int position = viewHolder.getAdapterPosition();
                                            String id = itemsRecyclerAdapter.getItem(position).getItemId();
                                            realm.executeTransactionAsync(realm -> {
                                                Task item = realm.where(Task.class)
                                                        .equalTo("itemId", id)
                                                        .findFirst();
                                                if (item != null) {
                                                    item.deleteFromRealm();
                                                }
                                            });
                                            dialog.cancel();
                                        }
                                    });
                            alertDialog2.setNegativeButton("NO",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    });
                            alertDialog2.show();
                        }
                    });
                }
            };

            ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
            itemTouchHelper.attachToRecyclerView(recyclerView);
        }
        catch(Exception e){
            String error = e.toString();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(),"An error occurred, Please find the details below : "+error,Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
         priorityValue = parent.getItemAtPosition(position).toString();
    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    private RealmResults<Task> setUpRealm(String status) {
        SyncConfiguration configuration = SyncUser.current()
                .createConfiguration(REALM_BASE_URL + "/default")
                .build();
        realm = Realm.getInstance(configuration);

        if(("Completed").equalsIgnoreCase(status) || ("Pending").equalsIgnoreCase(status)){
            return realm
                    .where(Task.class)
                    .equalTo("status", status)
                    .sort("status", Sort.DESCENDING)
                    .findAllAsync();
        }
        return realm
                .where(Task.class)
                .sort("status", Sort.DESCENDING)
                .findAllAsync();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        realm.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_items, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.action_showall:
                Toast.makeText(getApplicationContext(),"Select All",Toast.LENGTH_LONG).show();
                fetchDataFromDB("All text","All",true);
                return true;
            case R.id.action_showcompleted:
                Toast.makeText(getApplicationContext(),"Show Completed",Toast.LENGTH_LONG).show();
                fetchDataFromDB("Completed text","Completed",true);
                return true;
            case R.id.action_showpending:
                Toast.makeText(getApplicationContext(),"Show Pending",Toast.LENGTH_LONG).show();
                fetchDataFromDB("Pending text","Pending",true);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
