package com.example.sachi.group24_hw11;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Console;

import static com.example.sachi.group24_hw11.R.id.editText;
import static com.example.sachi.group24_hw11.R.id.radioButton8;
import static com.example.sachi.group24_hw11.R.id.radioGroup2;
import static com.example.sachi.group24_hw11.R.id.seekBar;

public class MainActivity extends AppCompatActivity {

    double bacLevel = 0.0;
    String status;
    int weightData = 0;
    String gender;
    String selectedRadioBtnValue = "1 oz";
    int changedValue = 5;
    TextView seekTextViewResult;
    Double bacResult = 0.0 ;
    String weightValue;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.imagenew);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        final Button saveButton = findViewById(R.id.button);
        final Button addDrinkBtn = findViewById(R.id.button2);
        final Button resetBtn = findViewById(R.id.button3);
        final ProgressBar simpleProgressBar = (ProgressBar) findViewById(R.id.progressBar2);
        final EditText weight = findViewById(R.id.editText);

        RadioGroup levelGroup = (RadioGroup) findViewById(R.id.radioGroup2);
        final RadioButton checkedRadioButton = (RadioButton) levelGroup.findViewById(levelGroup.getCheckedRadioButtonId());
        final SeekBar simpleSeekBar = (SeekBar) findViewById(R.id.seekBar); // initiate the Seek bar
        final Switch switchGender = (Switch) findViewById(R.id.switch3);
        final TextView weightResult = (TextView) (findViewById(R.id.textView7));
        final TextView bac = (TextView) findViewById(R.id.textView8);
        final String genderMale = String.valueOf(switchGender.getTextOn());
        final String genderFemale = String.valueOf(switchGender.getTextOff());
        gender = genderMale;

        seekTextViewResult = (TextView) (findViewById(R.id.textView6));
        seekTextViewResult.setText(String.valueOf(changedValue)+" %");

        int maxValue=simpleSeekBar.getMax(); // get maximum value of the Seek bar
        int seekBarValue = simpleSeekBar.getProgress(); //get the progress value of seekbar

        //Event listener for Switch
        switchGender.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){ gender = genderMale;
                }
                else{ gender = genderFemale;
                }
            }
        });

        //Event Listener for Save Button
        saveButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                weightValue = weight.getText().toString().trim();
                if (weightValue.matches(".*\\d+.*")) {
                    if (weightValue.equalsIgnoreCase("")) {
                        weight.setError("Enter the weight in lb");

                    } else {
                        weightData = Integer.parseInt(weightValue);
                    }
                }
                else {
                    //weight.setError("Please enter a valid value for weight");
                    weight.setError("Enter the weight in lb");
                }
            }
        });

        //EventListener for Radio Group
        levelGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                RadioButton selectedRadioBtn = (RadioButton) group.findViewById(checkedId);
                boolean selectedOz = selectedRadioBtn.isChecked();
                selectedRadioBtnValue = String.valueOf(selectedRadioBtn.getText());
                /*if (selectedOz)
                {
                    Log.d("demo", selectedRadioBtnValue);

                }*/
            }
        });

        //Event Listener for Seekbar
        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                changedValue = progress;
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                seekTextViewResult.setText(String.valueOf(changedValue)+" %");
            }
        });

        //Event Listener for Add Drink Button
        addDrinkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                weightValue= weight.getText().toString().trim();

                if (weightValue.equalsIgnoreCase(""))
                {
                    weight.setError("Enter the weight in lb(numbers only)");
                    return;
                }

                else
                {

                int ozLev = Integer.parseInt(selectedRadioBtnValue.split(" ")[0]);
                float numerator = ((changedValue*1.0f)/100.0f * ozLev);

                bacResult +=  numerator * 6.24 /
                        (
                                ((weightData == 0) ? 1 : weightData) * (gender.equals("M")? 0.68 : 0.55)
                        )
                        ;

                bac.setText(String.valueOf((double)Math.round(bacResult * 100d) / 100d));

                simpleProgressBar.setProgress((int) (bacResult*100));

                if (bacResult  <= 0.08 ){
                    status = "You are Safe";
                    weightResult.setBackgroundColor(0xFF00FF00);
                }
                else if (bacResult  > 0.08 && bacResult < 0.20){
                    status = "Be Careful...";
                    weightResult.setBackgroundColor(0xFFFFFF00);
                }
                else if (bacResult >= .20 && bacResult < .25){
                    status = "Over the limit!";
                    weightResult.setBackgroundColor(0xFFFF0000);
                }
                else if (bacResult >= .25){
                    status = "Over the limit!";
                    String displayMsg = "No more drinks for you.";
                    status = "Over the limit!";
                    weightResult.setBackgroundColor(0xFFFF0000);

                    //simpleProgressBar.setProgress((int) (bacResult*100));

                    int toastTime = Toast.LENGTH_LONG;
                    addDrinkBtn.setEnabled(false);
                    saveButton.setEnabled(false);
                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 300, 700);
                    displayToast.show();
                }
                weightResult.setText(status);

            }}
        });

        //Event handler for reset button
        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weightData = 0;
                weightValue = "";
                gender = "M";
                switchGender.setChecked(true);
                selectedRadioBtnValue = "1 oz";
                changedValue = 5;
                bacResult = 0.0 ;
                bac.setText("");
                weightResult.setText("");
                weight.getText().clear();
                seekTextViewResult.setText(String.valueOf(changedValue)+" %");
                simpleSeekBar.setProgress(0);
                checkedRadioButton.toggle();
                addDrinkBtn.setEnabled(true);
                saveButton.setEnabled(true);
                simpleProgressBar.setProgress((int) (bacResult*100));
                weightResult.setBackgroundColor(0xFFFFFFFF);

            }
        });

    }}
