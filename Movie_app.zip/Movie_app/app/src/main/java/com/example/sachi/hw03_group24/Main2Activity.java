package com.example.sachi.hw03_group24;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.example.sachi.hw03_group24.MainActivity.movieMap;
import static com.example.sachi.hw03_group24.MainActivity.movieNameList;

public class Main2Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Button addMovieBtn;
    Spinner spinner;
    SeekBar simpleSeekBar;
    int changedValue;
    TextView seekTextViewResult;
    EditText movieName;
    EditText description;
    EditText year;
    EditText imdb;
    Movie movie = new Movie();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle(R.string.add_movie);

        addMovieBtn = findViewById(R.id.button6);
        spinner = (Spinner) findViewById(R.id.spinner);
        simpleSeekBar = (SeekBar) findViewById(R.id.seekBar);
        seekTextViewResult = findViewById(R.id.textView7);

        movieName = findViewById(R.id.editText);
        description = findViewById(R.id.editText2);
        year = findViewById(R.id.editText3);
        imdb = findViewById(R.id.editText4);

        movie.setRating(0);
        movie.setGenre("Action");

        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

        Bundle b = getIntent().getExtras();
        ArrayList<String> categories = getIntent().getStringArrayListExtra("categoriss");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        seekTextViewResult.setText(String.valueOf(0));

        //Event Listener for Seekbar
        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                changedValue = progress;
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                seekTextViewResult.setText(String.valueOf(changedValue));
                movie.setRating(changedValue);
            }
        });

        //Event handler for add button
        addMovieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String movienm = movieName.getText().toString().trim();
                String desc = description.getText().toString().trim();
                String yr = year.getText().toString().trim();
                String imdbdata = imdb.getText().toString();

                if (movienm.length() == 0 || desc.length() == 0 || yr.length() == 0 || imdbdata.length() == 0) {
                            String msg = (movienm.length() == 0 ? "Please enter valid movie name!" :
                                    (desc.length() == 0 ? "Please enter movie description!" :
                                            (yr.length() == 0 ? "Please enter valid year!" :
                                                    (imdbdata.length() == 0 ? "Please enter valid imdb link!": "You are good to go")
                                            )
                                    ));

                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, msg, Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP | Gravity.LEFT, 225, 700);
                    displayToast.show();
                }
                else {
                    movie.setName(movienm);
                    movie.setDesctiption(desc);
                    movie.setYear(Integer.parseInt(String.valueOf(yr)));
                    movie.setImdb(imdbdata);

                    movieMap.put(movienm, movie);
                    movieNameList = movieMap.keySet();
                    Intent intent = new Intent(Main2Activity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
            }
        );
    }
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String item = parent.getItemAtPosition(position).toString();
            movie.setGenre(item);
        }
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
}
