package com.example.sachi.hw03_group24;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Main5Activity extends AppCompatActivity {
    TextView title;
    TextView description;
    TextView genre;
    TextView rating;
    TextView year;
    TextView imdb;
    ImageView previous;
    ImageView next;
    ImageView first;
    ImageView last;
    Button finish;


    ArrayList<Movie> movieNameList;
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.movies_by_rating);
        setContentView(R.layout.activity_main5);

        movieNameList = getIntent().getExtras().getParcelableArrayList("movie");

        title = findViewById(R.id.textView5);
        description = findViewById(R.id.textView6);
        genre = findViewById(R.id.textView7);
        rating = findViewById(R.id.textView15);
        year = findViewById(R.id.textView16);
        imdb = findViewById(R.id.textView17);

        previous = findViewById(R.id.imageView);
        next = findViewById(R.id.imageView2);
        first = findViewById(R.id.imageView3);
        last = findViewById(R.id.imageView4);

        finish = findViewById(R.id.button7);

        i=0;
        Movie movie = movieNameList.get(i);

        title.setText(movie.getName());
        description.setText(movie.getDesctiption());
        genre.setText(movie.getGenre());
        rating.setText(String.valueOf(movie.getRating())+"/5");
        year.setText(String.valueOf(movie.getYear()));
        imdb.setText(movie.getImdb());

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i!=movieNameList.size()-1){
                    i+=1;
                }
                else{
                    i = movieNameList.size()-1;
                }
                Movie movie = movieNameList.get(i);
                title.setText(movie.getName());
                description.setText(movie.getDesctiption());
                genre.setText(movie.getGenre());
                rating.setText(String.valueOf(movie.getRating())+"/5");
                year.setText(String.valueOf(movie.getYear()));
                imdb.setText(movie.getImdb());
            }});

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(i!=0){ i-=1;}
                else {i=0;}
                Movie movie = movieNameList.get(i);
                title.setText(movie.getName());
                description.setText(movie.getDesctiption());
                genre.setText(movie.getGenre());
                rating.setText(String.valueOf(movie.getRating())+"/5");
                year.setText(String.valueOf(movie.getYear()));
                imdb.setText(movie.getImdb());
            }});

        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i=0;
                Movie movie = movieNameList.get(i);
                title.setText(movie.getName());
                description.setText(movie.getDesctiption());
                genre.setText(movie.getGenre());
                rating.setText(String.valueOf(movie.getRating())+"/5");
                year.setText(String.valueOf(movie.getYear()));
                imdb.setText(movie.getImdb());
            }});

        last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = movieNameList.size()-1;
                Movie movie = movieNameList.get(i);
                title.setText(movie.getName());
                description.setText(movie.getDesctiption());
                genre.setText(movie.getGenre());
                rating.setText(String.valueOf(movie.getRating())+"/5");
                year.setText(String.valueOf(movie.getYear()));
                imdb.setText(movie.getImdb());
            }});


        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main5Activity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}