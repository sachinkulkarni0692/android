package com.example.sachi.hw03_group24;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    Button addMovieBtn;
    Button editMovieBtn;
    Button deleteMovieBtn;
    Button listByYrBtn;
    Button listByRatingBtn;

    public static Map<String,Movie> movieMap = new HashMap<>();
    public static Map<String,Integer> categoryMap;
    public static Set<String> movieNameList = new HashSet<>();
    public static ArrayList<String> categories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.fav_movies);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        addMovieBtn = findViewById(R.id.button);
        editMovieBtn = findViewById(R.id.button2);
        deleteMovieBtn = findViewById(R.id.button3);
        listByYrBtn = findViewById(R.id.button4);
        listByRatingBtn = findViewById(R.id.button5);

        categoryMap = new HashMap<>();
        categories = new ArrayList<>();

        categories.add("Action");
        categories.add("Animation");
        categories.add("Comedy");
        categories.add("Documentary");
        categories.add("Family");
        categories.add("Horror");
        categories.add("Crime");
        categories.add("Others");

        categoryMap.put("Action",1);
        categoryMap.put("Animation",2);
        categoryMap.put("Comedy",3);
        categoryMap.put("Documentary",4);
        categoryMap.put("Family",5);
        categoryMap.put("Horror",6);
        categoryMap.put("Crime",7);
        categoryMap.put("Others",8);

        //Event Listener for add Button
        addMovieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                intent.putStringArrayListExtra("categoriss",categories);
                startActivity(intent);
            }
        });

        //Event Listener for edit Button
        editMovieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (movieNameList.size()!=0){
                    List<String> keyList = new ArrayList<String>(movieNameList);
                    final ArrayAdapter<String> adp = new ArrayAdapter<String>(MainActivity.this,
                                                            android.R.layout.simple_list_item_1, keyList);
                    final ListView sp = new ListView(MainActivity.this);
                    sp.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT));
                    sp.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
                    sp.setAdapter(adp);

                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Pick a movie");
                    builder.setView(sp);
                    builder.create().show();

                    sp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        public void onItemClick(AdapterView<?> listView, View itemView, int itemPosition, long itemId)
                        {
                            Intent intents = new Intent(MainActivity.this,Main3Activity.class);
                            intents.putExtra("movieSelected",String.valueOf(itemPosition));
                            intents.putStringArrayListExtra("categoriss",categories);
                            startActivity(intents);
                        }
                    });
            }
                else {

                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, "No movies to choose from!!", Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                    displayToast.show();
                }
            }
        }
        );

        //Event Listener for delete button
        deleteMovieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if (movieNameList.size()!=0){
                 List<String> keyList = new ArrayList<String>(movieNameList);
                 final ArrayAdapter<String> adp = new ArrayAdapter<String>(MainActivity.this,
                    android.R.layout.simple_list_item_1, keyList);

                 final ListView sp = new ListView(MainActivity.this);

                 sp.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                 sp.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
                 sp.setAdapter(adp);

                 AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                 builder.setTitle("Pick a movie");
                 builder.setView(sp);

                 final AlertDialog alert = builder.create();
                 alert.show();
                 sp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                     public void onItemClick(AdapterView<?> listView, View itemView, int itemPosition, long itemId)
                    {
                        List<String> keyList = new ArrayList<String>(movieNameList);
                        String movieName = keyList.get(Integer.parseInt(String.valueOf(itemPosition)));
                        movieMap.remove(movieName);
                        Context appContext = getApplicationContext();
                        String msg = "The movie "+movieName+" has been deleted!!";
                        Toast displayToast = Toast.makeText(appContext, msg, Toast.LENGTH_LONG);
                        displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                        displayToast.show();
                        alert.cancel();
                    }
                    });

            }
                else {
                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, "No movies to choose from!!", Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                    displayToast.show();
                }}
        }
        );

        //Event Listener for list by year button
        listByYrBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (movieNameList.size()!=0){
                ArrayList<Movie> movies = new ArrayList<Movie>(movieMap.values());
                Collections.sort(movies,
                        new Comparator<Movie>() {
                            @Override
                            public int compare(Movie o1, Movie o2) {
                                return o1.getYear()- o2.getYear();
                            }
                        }
                );

                Intent intent = new Intent(MainActivity.this,Main4Activity.class);
                intent.putParcelableArrayListExtra("movie", movies);
                startActivity(intent);
                }
                else {
                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, "Please add some Movies to sort!", Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                    displayToast.show();
                }
            }
        }
        );

        //Event Listener for list by rating button
        listByRatingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (movieNameList.size()!=0){
                    ArrayList<Movie> movies = new ArrayList<Movie>(movieMap.values());
                    Collections.sort(movies,
                            new Comparator<Movie>() {
                                @Override
                                public int compare(Movie o1, Movie o2) {
                                    return o2.getRating()- o1.getRating();
                                }
                            }
                    );

                    Intent intent = new Intent(MainActivity.this,Main5Activity.class);
                    intent.putParcelableArrayListExtra("movie", movies);
                    startActivity(intent);
                }
                else {
                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, "Please add some Movies to sort!", Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                    displayToast.show();
                }

            }
        }
     );
 }
}