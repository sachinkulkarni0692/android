package com.example.sachi.hw03_group24;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static com.example.sachi.hw03_group24.MainActivity.movieMap;
import static com.example.sachi.hw03_group24.MainActivity.movieNameList;

public class Main3Activity extends AppCompatActivity{

    Button saveMovieBtn;
    Spinner spinner;
    SeekBar simpleSeekBar;
    int changedValue;
    TextView seekTextViewResult;
    EditText movieName;
    EditText description;
    EditText year;
    EditText imdb;
    Movie movie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.edit_movie);
        setContentView(R.layout.activity_main3);

        Bundle b = getIntent().getExtras();
        final String selectedMovie = (String) b.get("movieSelected");
        ArrayList<String> categories = getIntent().getStringArrayListExtra("categoriss");
        final List<String> keyList = new ArrayList<String>(movieNameList);

        movie = movieMap.get(
                keyList.get(Integer.parseInt(
                        selectedMovie)
                ));

        saveMovieBtn = findViewById(R.id.button6);
        spinner = (Spinner) findViewById(R.id.saveSpinner);
        simpleSeekBar = (SeekBar) findViewById(R.id.seekBar);
        seekTextViewResult = findViewById(R.id.textView7);

        movieName = findViewById(R.id.editText);
        description = findViewById(R.id.editText2);
        year = findViewById(R.id.editText3);
        imdb = findViewById(R.id.editText4);

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);

        movieName.setText(movie.getName());
        description.setText(movie.getDesctiption());

        int spinnerPosition = dataAdapter.getPosition(movie.getGenre());
        spinner.setSelection(spinnerPosition);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String item = parent.getItemAtPosition(position).toString();
            movie.setGenre(item);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        simpleSeekBar.setProgress(movie.getRating());
        seekTextViewResult.setText(String.valueOf(movie.getRating()));

        year.setText(String.valueOf(movie.getYear()==0 ? "" : movie.getYear()));
        imdb.setText(movie.getImdb());

        //Event Listener for Seekbar
        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                changedValue = progress;
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                seekTextViewResult.setText(String.valueOf(changedValue));
                movie.setRating(changedValue);
            }
        });

        movieMap.remove(movie.getName());

        saveMovieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               String movienm = movieName.getText().toString().trim();
               String desc = description.getText().toString().trim();
               String yr = year.getText().toString().trim();
               String imdbdata = imdb.getText().toString();

                if (movienm.length() == 0 || desc.length() == 0 || yr.length() == 0 || imdbdata.length() == 0) {
                    String msg = (movienm.length() == 0 ? "Please enter valid movie name!" :
                            (desc.length() == 0 ? "Please enter movie description!" :
                                    (yr.length() == 0 ? "Please enter valid year!" :
                                            (imdbdata.length() == 0 ? "Please enter valid imdb link!": "You are good to go")
                                    )
                            ));

                    Context appContext = getApplicationContext();
                    Toast displayToast = Toast.makeText(appContext, msg, Toast.LENGTH_LONG);
                    displayToast.setGravity(Gravity.TOP | Gravity.LEFT, 225, 700);
                    displayToast.show();
                }
                else{
                    movie.setName(movienm);
                    movie.setDesctiption(desc);
                    movie.setYear(Integer.parseInt(String.valueOf(yr)));
                    movie.setImdb(imdbdata);

                   if (!selectedMovie.equalsIgnoreCase(movienm)){
                       movieNameList = movieMap.keySet();
                   }

                   movieMap.put(movienm,movie);
                   Intent intent = new Intent(Main3Activity.this, MainActivity.class);
                   startActivity(intent);
                }
             }
          }
        );
    }
}