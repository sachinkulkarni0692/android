package com.example.sachi.photogallery;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class DisplayImage extends AsyncTask<String, Integer, Bitmap> {

    private AsyncImageListener listener;

    public DisplayImage(AsyncImageListener listener){
        this.listener = listener;
    }


    protected Bitmap doInBackground(String... strings) {
        //Bitmap bitmap = null;
        try{
            URL url = null;

            try {
                    List<String> retreivedUrls = MainActivity.urlMap.get(strings[0]);
                    url = new URL(retreivedUrls.get(MainActivity.i).replace(".jpg", "") + ".jpg");
                    Log.d("URL", String.valueOf(url));
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    return BitmapFactory.decodeStream(connection.getInputStream());

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    @Override
    protected void onPostExecute(Bitmap bitmap){
        listener.getBitmap(bitmap);
    }

    public interface AsyncImageListener {
        public void getBitmap(Bitmap bitmap);
    }
}