package com.example.sachi.photogallery;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements GetKeywords.KeywordInterface,Geturls.URLInterface,DisplayImage.AsyncImageListener{
    ExecutorService threadpool;
    static HashMap<String, List<String>> urlMap = new HashMap<>();
    List<String> urls;
    TextView tView;
    String key;
    static int i;
    ImageView iv;
    ImageView next;
    ImageView previous;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button gobtn = findViewById(R.id.button);
        iv = findViewById(R.id.imageView);
        next = findViewById(R.id.imageView3);
        previous = findViewById(R.id.imageView2);
        progressBar = findViewById(R.id.progressBar);
        threadpool = Executors.newFixedThreadPool(4);

        next.setVisibility(View.INVISIBLE);
        previous.setVisibility(View.INVISIBLE);

        gobtn.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         if(isConnected()){
                                             Log.d("msg","internet connected");
                                             progressBar.setVisibility(View.VISIBLE);
                                             iv.setVisibility(View.INVISIBLE);
                                             new GetKeywords(MainActivity.this).execute("http://dev.theappsdr.com/apis/photos/keywords.php");
                                         }
                                         else{
                                             Context appContext = getApplicationContext();
                                             String msg = "No Internet Connection!!";
                                             Toast displayToast = Toast.makeText(appContext, msg, Toast.LENGTH_LONG);
                                             displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                                             displayToast.show();
                                         }

                                     }
                                 }
        );



    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkinfo = connectivityManager.getActiveNetworkInfo();

        if ((networkinfo == null) || !networkinfo.isConnected() ||
                ((networkinfo.getType() != connectivityManager.TYPE_WIFI) && (networkinfo.getType() != connectivityManager.TYPE_MOBILE))){
            return false;
        }
        return true;
    }

    @Override
    public void onkinterfaceExecute(String res){
        final List<String> keyList = Arrays.asList(res.split(";"));

        final ArrayAdapter<String> adp = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, keyList);
        final ListView sp = new ListView(MainActivity.this);
        sp.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        sp.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
        sp.setAdapter(adp);

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Choose a Keyword");
        builder.setView(sp);
        final AlertDialog alert = builder.create();
        alert.show();
        sp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> listView, View itemView, int itemPosition, long itemId)
            {
                String keyword = keyList.get(Integer.parseInt(String.valueOf(itemPosition)));
                key = keyword;
                i=0;
                tView = findViewById(R.id.textView2);
                tView.setText(keyword);
                alert.cancel();
                new Geturls(MainActivity.this).execute("http://dev.theappsdr.com/apis/photos/index.php?keyword="+keyword);
            }
        });

    }

    @Override
    public void onUrlInterfaceExecute(String keyword){
        try{
            if (keyword.trim().length()!=0){
                urls = Arrays.asList(keyword.toString().split(".jpg"));
                if (urlMap.containsKey(key)){urlMap.remove(key);}
                urlMap.put(key, urls);
                new DisplayImage(MainActivity.this).execute(key);
            }
            else{
                Context appContext = getApplicationContext();
                String msg = "No images Found!!";
                Toast displayToast = Toast.makeText(appContext, msg, Toast.LENGTH_LONG);
                displayToast.setGravity(Gravity.TOP| Gravity.LEFT, 225, 700);
                progressBar.setVisibility(View.INVISIBLE);
                displayToast.show();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void getBitmap(Bitmap bitmap) {
        final List<String> retreivedUrls = urlMap.get(key);
        if (retreivedUrls.size()==1){
            next.setVisibility(View.INVISIBLE);
            previous.setVisibility(View.INVISIBLE);
        }
        else {
            next.setVisibility(View.VISIBLE);
            previous.setVisibility(View.VISIBLE);
        }

        previous.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if(i!=0){
                                                i-=1;
                                            }
                                            else {
                                                i=0;
                                            }
                                            progressBar.setVisibility(View.VISIBLE);
                                            iv.setVisibility(View.INVISIBLE);
                                            new DisplayImage(MainActivity.this).execute(key);
                                        }
                                    }
        );

        next.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (i!=retreivedUrls.size()-1){
                                            i+=1;
                                        }
                                        else{
                                            i = retreivedUrls.size()-1;
                                        }
                                        progressBar.setVisibility(View.VISIBLE);
                                        iv.setVisibility(View.INVISIBLE);
                                        new DisplayImage(MainActivity.this).execute(key);
                                    }
                                }
        );

        if (bitmap!=null){
            progressBar.setVisibility(View.INVISIBLE);
            iv.setVisibility(View.VISIBLE);
            iv.setImageBitmap(bitmap);
        }
    }
}


