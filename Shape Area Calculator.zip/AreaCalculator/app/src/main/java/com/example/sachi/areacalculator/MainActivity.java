package com.example.sachi.areacalculator;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String lng1read = "";
    String lng2read = "";
    double lenght1read = 0;
    double lenght2read = 0;
    String shape = "";
    String areaFinal = "";
    double area;
    int type = 0;
    public boolean trselected;
    public boolean sqselected;
    public boolean ciselected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    //Initialing all the elements from the layout
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button calculate = findViewById(R.id.button);
        final Button clear = findViewById(R.id.button2);
        final TextView selectShape = findViewById(R.id.textView);
        final TextView areaDisplay = findViewById(R.id.editText3);
        final EditText length1 = findViewById(R.id.editText2);
        final EditText lenght2 = findViewById(R.id.editText);
        final ImageView triangle = findViewById(R.id.imageView);
        final ImageView square = findViewById(R.id.imageView2);
        final ImageView circle = findViewById(R.id.imageView3);
        final TextView txtlength1 = findViewById(R.id.textView3);
        final TextView txtlenght2 = findViewById(R.id.textView2);

        //Verifying the shape selected

        triangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectShape.setText("Triangle");
                areaDisplay.setText("");
                sqselected = false;
                trselected = true;
                ciselected = false;
                txtlength1.setVisibility(View.VISIBLE);
                txtlenght2.setVisibility(View.VISIBLE);
                length1.setVisibility(View.VISIBLE);
                lenght2.setVisibility(View.VISIBLE);

            }});
        square.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectShape.setText("Square");
                areaDisplay.setText("");
                sqselected = true;
                trselected = false;
                ciselected = false;
                txtlength1.setVisibility(View.VISIBLE);
                txtlenght2.setVisibility(View.INVISIBLE);
                length1.setVisibility(View.VISIBLE);
                lenght2.setVisibility(View.INVISIBLE);
            }});
        circle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectShape.setText("circle");
                areaDisplay.setText("");
                sqselected = false;
                trselected = false;
                ciselected = true;
                txtlength1.setVisibility(View.VISIBLE);
                txtlenght2.setVisibility(View.INVISIBLE);
                length1.setVisibility(View.VISIBLE);
                lenght2.setVisibility(View.INVISIBLE);
            }});
        //Calculating the area based on the selected shape
        calculate.setOnClickListener(new View.OnClickListener()
        {@Override
            public void onClick(View v)
            {
                areaDisplay.setText("");
                if (trselected)
                    {
                        lng1read = length1.getText().toString().trim();
                        lng2read = lenght2.getText().toString().trim();
                        if ((lng1read.length() == 0) || (lng2read.length() == 0))
                        {
                            int toastTime = Toast.LENGTH_LONG;
                            Context appContext = getApplicationContext();
                            String displayMsg = "Enter all the dimension(s)!";
                            Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                            displayToast.setGravity(Gravity.TOP | Gravity.LEFT, 300, 700);
                            displayToast.show();
                        }
                        else
                        {
                            lenght2read = Double.parseDouble(lng2read);
                            lenght1read = Double.parseDouble(lng1read);
                            area = (.5 * lenght1read * lenght2read * 100d) / 100d;
                            areaFinal = String.valueOf(area);
                            areaDisplay.setText(areaFinal);
                        }
                    }
                else if (sqselected)
                    {
                        lng1read = length1.getText().toString().trim();
                        if (lng1read.length() == 0)
                        {
                            int toastTime = Toast.LENGTH_LONG;
                            Context appContext = getApplicationContext();
                            String displayMsg = "Enter length 1!";
                            Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                            displayToast.setGravity(Gravity.TOP | Gravity.LEFT, 350, 700);
                            displayToast.show();
                        }
                        else
                        {
                            lenght1read = Double.parseDouble(lng1read);
                            area = Math.round(lenght1read * lenght1read * 100d) / 100d;
                            areaFinal = String.valueOf(area);
                            areaDisplay.setText(areaFinal);
                        }
                    }
                else if (ciselected)
                    {
                        lng1read = length1.getText().toString().trim();
                        if (lng1read.length() == 0)
                        {
                            int toastTime = Toast.LENGTH_LONG;
                            Context appContext = getApplicationContext();
                            String displayMsg = "Enter length 1!";
                            Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                            displayToast.setGravity(Gravity.TOP | Gravity.LEFT, 350, 700);
                            displayToast.show();
                        }
                        else
                        {
                            lenght1read = Double.parseDouble(lng1read);
                            area = Math.round(3.1416 * lenght1read * lenght1read * 100d) / 100d;
                            areaFinal = String.valueOf(area);
                            areaDisplay.setText(areaFinal);
                        }
                    }
                else  if (!sqselected && !trselected && !ciselected)
                {
                    int toastTime = Toast.LENGTH_LONG;
                    Context appContext = getApplicationContext();
                    String displayMsg = "Select a shape!";
                    Toast displayToast = Toast.makeText(appContext, displayMsg, toastTime);
                    displayToast.setGravity(Gravity.TOP | Gravity.LEFT, 350, 700);
                    displayToast.show();
                }
            }
            });
        //Resetting the fields after the clear button is clicked
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtlength1.setVisibility(View.VISIBLE);
                txtlenght2.setVisibility(View.VISIBLE);
                length1.setVisibility(View.VISIBLE);
                lenght2.setVisibility(View.VISIBLE);
                String areaFinal = "";
                areaDisplay.setText("");
                length1.setText("");
                lenght2.setText("");
                lenght1read = 0;
                lenght2read = 0;
                selectShape.setText("Select a shape");
                area = 0;
                trselected = false;
                sqselected = false;
                ciselected = false;
            }
        });

    }
}
