package com.example.pabhivarshnv.chatroom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ocpsoft.prettytime.PrettyTime;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ChatRoomActivity extends AppCompatActivity {

    EditText message;
    TextView chatroomTitle;
    ImageView home;
    ImageView send;
    ListView listChatroomMessages;

    Chat chat = new Chat();
    User user = new User();
    SharedPreferences preferences = null;
    String loggedInUserId = null;

    private static String API_GET_MESSAGES = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/messages/";
    private static String API_POST_MESSAGE = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/message/add";
    private static String API_DELETE_MESSAGE = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/message/delete/";

    private AlertDialog progressDialog;
    String thread_id;

    ArrayList<Message> listMsg = new ArrayList<Message>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatroom);
        setTitle("Chatroom");

        message = findViewById(R.id.editText_msg);
        chatroomTitle = findViewById(R.id.textView_chatTitle);
        home = findViewById(R.id.imageView_home);
        send = findViewById(R.id.imageView_sendMessage);
        listChatroomMessages = findViewById(R.id.listview_chatroom);

        if(getIntent()!=null && getIntent().getExtras()!=null){
            Intent intent = getIntent();
            String json = intent.getStringExtra("listViewJson");
            String userJson = intent.getStringExtra("user");
            Gson gson = new Gson();
            chat = gson.fromJson(json,Chat.class);
            user = gson.fromJson(userJson,User.class);

            Log.d("demo", "onCreate: "+chat.getTitle());
            preferences = getSharedPreferences("MY_PREFERENCES",MODE_PRIVATE);
            preferences.edit().remove("token").commit();
            preferences.edit().putString("token", user.getToken()).commit();

            loggedInUserId = user.getUser_id();

            chatroomTitle.setText(chat.getTitle());
            thread_id = chat.getId();
            if (isConnected()){
                showProgress("Loading...");
                new LoadMessagesChatroom().execute(API_GET_MESSAGES);
            }
        }

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!message.getText().toString().isEmpty()){
                    showProgress("Loading...");

                    addMessage(message.getText().toString());
                    message.setText("");
                    new LoadMessagesChatroom().execute(API_GET_MESSAGES);
                }
                else {
                    Toast.makeText(ChatRoomActivity.this, "please enter the message!!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void showProgress(String title) {
        LinearLayout linearLayout = getLinearLayout();

        ProgressBar progress = new ProgressBar(this);
        TextView message = new TextView(this);
        message.setText(title);
        linearLayout.addView(progress);
        linearLayout.addView(message);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setCancelable(false);
        dialogBuilder.setView(linearLayout);
        progressDialog = dialogBuilder.create();
        progressDialog.show();
    }

    public LinearLayout getLinearLayout(){
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setPadding(40, 40, 40, 40);
        linearLayout.setGravity(Gravity.CENTER);

        return linearLayout;
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService( Context.CONNECTIVITY_SERVICE );
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != ConnectivityManager.TYPE_WIFI && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        } else
            return true;
    }

    class LoadMessagesChatroom extends AsyncTask<String, Integer, ArrayList<Message>>{

        @Override
        protected void onPostExecute(ArrayList<Message> msg) {
            ChatRoomActivity.MessageAdapter mta = new ChatRoomActivity.MessageAdapter(ChatRoomActivity.this,R.layout.activity_message,msg);

            listChatroomMessages.setAdapter(mta);
            progressDialog.dismiss();
        }

        @Override
        protected ArrayList<Message> doInBackground(String... strings) {

            listMsg.clear();
            OkHttpClient client = new OkHttpClient();

            Request loadMessages = new Request.Builder()
                    .header("Authorization","BEARER "+preferences.getString("token",null))
                    .url(strings[0]+thread_id)
                    .build();
            Response response = null;
            try {
                response = client.newCall(loadMessages).execute();
                if (response.isSuccessful()){
                    final JSONObject root = new JSONObject(response.body().string());
                    String status = root.getString("status");
                    progressDialog.dismiss();
                    if (status.equals("ok")){
                        Gson gson = new Gson();
                        String json = gson.toJson(root);
                        Log.d("demo", "doInBackground: "+json);
                        JSONArray jsonArray = new JSONArray(root.getString("messages"));
                        Log.d("demo", "doInBackground: jsonarray "+jsonArray);
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            Message msg = new Message();
                            msg.setUser_fname(jsonObject.getString("user_fname"));
                            msg.setUser_lname(jsonObject.getString("user_lname"));
                            msg.setUser_id(jsonObject.getString("user_id"));
                            msg.setId(jsonObject.getString("id"));
                            msg.setMessage(jsonObject.getString("message"));
                            msg.setStatus(root.getString("status"));
                            msg.setCreated_at(jsonObject.getString("created_at"));

                            listMsg.add(msg);
                        }

                    }
                    else {
                        ChatRoomActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Toast.makeText(ChatRoomActivity.this, root.getString("message"), Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            Collections.reverse(listMsg);
            return listMsg;
        }
    }

    private void addMessage(String msg){

        OkHttpClient client = new OkHttpClient();
        Log.d("demo", "addMessage: "+thread_id+" : "+preferences.getString("token",null));

        RequestBody formBody = new FormBody.Builder()
                .add("message",msg)
                .add("thread_id",thread_id)
                .build();

        Request addMsg = new Request.Builder()
                .header("Authorization","BEARER "+preferences.getString("token",null))
                .url(API_POST_MESSAGE)
                .post(formBody)
                .build();

        client.newCall(addMsg).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                try {
                    final JSONObject root = new JSONObject(response.body().string());
                    String status = root.getString("status");
                    progressDialog.dismiss();
                    if (status.equals("ok")){
                        Gson gson = new Gson();
                        String json = gson.toJson(root);
                        Log.d("demo", "onResponse: addMessage "+json);
                        ChatRoomActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(ChatRoomActivity.this, "message has been added successfully!!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else {
                        ChatRoomActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Toast.makeText(ChatRoomActivity.this, root.getString("message"), Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    class MessageAdapter extends ArrayAdapter<Message> {

        Context context;
        ArrayList<Message> objects;


        public MessageAdapter(@NonNull Context context, int resource, @NonNull List<Message> objects) {
            super(context, resource, objects);
            this.context = context;
            this.objects = (ArrayList<Message>) objects;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            ChatRoomActivity.MessageAdapter.ViewHandler viewHandler;
            if(convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.activity_message, parent, false);
                viewHandler = new ChatRoomActivity.MessageAdapter.ViewHandler();
                viewHandler.msg = convertView.findViewById(R.id.textView_sentMsg);
                viewHandler.userName = convertView.findViewById(R.id.textView_userName);
                viewHandler.timeElapsed = convertView.findViewById(R.id.textView_timeElapsed);
                viewHandler.imgDelete = convertView.findViewById(R.id.imageView_delete);
                convertView.setTag(viewHandler);
            }

            viewHandler = (ChatRoomActivity.MessageAdapter.ViewHandler) convertView.getTag();
            Message messageThread = objects.get(position);
            PrettyTime p = new PrettyTime();
            try {
                Date date=new SimpleDateFormat("yyyy-MM-dd hh:mm:sss").parse(messageThread.getCreated_at());
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                cal.add(Calendar.HOUR, -4);
                Date createdTime = cal.getTime();
                Log.d("demo", "getView: timeElapsed: "+p.format(createdTime));
                messageThread.setCreated_at(p.format(createdTime));

            } catch (ParseException e) {
                e.printStackTrace();
            }
            ImageView imgDelete = viewHandler.imgDelete;
            TextView userName = viewHandler.userName;
            TextView timeElapsed = viewHandler.timeElapsed;
            TextView msg = viewHandler.msg;
            Log.d("demo", "getView: userId"+messageThread.getUser_id()+" : "+messageThread.getId());

            userName.setText(messageThread.getUser_fname()+" "+messageThread.getUser_lname());
            msg.setText(messageThread.getMessage());
            timeElapsed.setText(messageThread.getCreated_at());

            imgDelete.setVisibility(View.INVISIBLE);
            if (messageThread.getUser_id().toString().equals(loggedInUserId.toString())){
                imgDelete.setVisibility(View.VISIBLE);
            }
            imgDelete.setTag(position);
            imgDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isConnected()){
                        int i = (int) view.getTag();
                        Message item = getItem(i);
                        Log.d("demo", "onClick: in delete"+item.getId());
                        deleteThread(API_DELETE_MESSAGE,item.getId());
                        new LoadMessagesChatroom().execute(API_GET_MESSAGES);
                    }
                }
            });

            return convertView;
        }

        class ViewHandler{
            TextView msg;
            TextView userName;
            TextView timeElapsed;
            ImageView imgDelete;
        }
    }

    private void deleteThread(String apiDeleteMessage, String id) {

        OkHttpClient client = new OkHttpClient();

        Request deleteMessage = new Request.Builder()
                .header("Authorization","BEARER "+preferences.getString("token",""))
                .url(apiDeleteMessage+id)
                .build();

        client.newCall(deleteMessage).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                try {
                    final JSONObject root = new JSONObject(response.body().string());
                    String status = root.getString("status");
                    progressDialog.dismiss();
                    if(status.equals("ok")){
                        ChatRoomActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(ChatRoomActivity.this, "message has been deleted successfully!!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else{
                        ChatRoomActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Toast.makeText(ChatRoomActivity.this, root.getString("message"), Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }
}
