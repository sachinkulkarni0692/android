package com.example.pabhivarshnv.chatroom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SignUpActivity extends AppCompatActivity {

    AlertDialog progressDialog = null;
    EditText fName;
    EditText lName;
    EditText email;
    EditText pwd;
    EditText rPwd;

    private static String API_SIGNUP = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/signup";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        setTitle("Sign Up");

        fName = findViewById(R.id.editText_fname);
        lName = findViewById(R.id.editText_lname);
        email = findViewById(R.id.editText_Email);
        pwd = findViewById(R.id.editText_pwd);
        rPwd = findViewById(R.id.editText_Rpwd);

        Button cancel = findViewById(R.id.button_cancel);
        Button SignUp = findViewById(R.id.button_signUp);



        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isConnected()){
                    if (rPwd.getText().toString().equals(pwd.getText().toString())){
                        OkHttpClient client = new OkHttpClient();
                        Log.d("demo", "onClick: "+email.getText().toString());
                        showProgress("Loading...");
                        RequestBody formBody = new FormBody.Builder()
                                .add("email",email.getText().toString())
                                .add("password",pwd.getText().toString())
                                .add("fname",fName.getText().toString())
                                .add("lname",lName.getText().toString())
                                .build();

                        Request signupRequest = new Request.Builder()
                                .url(API_SIGNUP)
                                .post(formBody)
                                .build();

                        client.newCall(signupRequest).enqueue(new Callback() {
                            @Override
                            public void onFailure(Call call, IOException e) {
                                progressDialog.dismiss();
                                e.printStackTrace();
                            }

                            @Override
                            public void onResponse(Call call, Response response) throws IOException {

                                try {
                                    final JSONObject root = new JSONObject(response.body().string());
                                    String status = root.getString("status");
                                    progressDialog.dismiss();
                                    if (status.equals("ok")){
                                        User user = new User();
                                        user.setStatus(root.getString("status"));
                                        user.setToken(root.getString("token"));
                                        user.setUser_email(root.getString("user_email"));
                                        user.setUser_fname(root.getString("user_fname"));
                                        user.setUser_lname(root.getString("user_lname"));
                                        user.setUser_role(root.getString("user_role"));
                                        user.setUser_id(root.getString("user_id"));

                                        SharedPreferences preferences = getSharedPreferences("MY_PREFERENCES", MODE_PRIVATE);
                                        preferences.edit().remove("token").commit();
                                        preferences.edit().putString("token",user.getToken()).commit();
                                        Gson gson = new Gson();
                                        String userObj = gson.toJson(user);
                                        preferences.edit().putString("userObj",userObj).commit();

                                        Intent intent = new Intent(SignUpActivity.this,MessageActivity.class);
                                        //intent.putExtra("userObj", (Serializable) user);
                                        startActivity(intent);
                                        finish();
                                    }
                                    else {
                                        SignUpActivity.this.runOnUiThread(new Runnable() {
                                            public void run() {
                                                try {
                                                    Toast.makeText(SignUpActivity.this, root.getString("message"), Toast.LENGTH_SHORT).show();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        });
                    }
                    else {
                        Toast.makeText(SignUpActivity.this, "Make sure both the passwords entered are same", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(SignUpActivity.this, "Please check you internet connection", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

    public void showProgress(String title) {
        LinearLayout linearLayout = getLinearLayout();

        ProgressBar progress = new ProgressBar(this);
        TextView message = new TextView(this);
        message.setText(title);
        linearLayout.addView(progress);
        linearLayout.addView(message);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setCancelable(false);
        dialogBuilder.setView(linearLayout);
        progressDialog = dialogBuilder.create();
        progressDialog.show();
    }

    public LinearLayout getLinearLayout(){
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setPadding(40, 40, 40, 40);
        linearLayout.setGravity(Gravity.CENTER);

        return linearLayout;
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService( Context.CONNECTIVITY_SERVICE );
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != ConnectivityManager.TYPE_WIFI && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        } else
            return true;
    }
}
