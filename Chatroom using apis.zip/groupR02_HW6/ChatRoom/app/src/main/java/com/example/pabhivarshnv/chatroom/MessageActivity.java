package com.example.pabhivarshnv.chatroom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.JsonReader;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MessageActivity extends AppCompatActivity {

    AlertDialog progressDialog = null;
    SharedPreferences preferences = null;
    String loggedInUserId = null;

    private static String API_GET_THREAD = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/thread";
    private static String API_ADD_THREAD = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/thread/add";
    private static String API_DELETE_THREAD = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/thread/delete/";

    EditText addNewThreadTitle;
    ImageView imageViewAddTitle;
    ListView titleList;
    ImageView logout;
    TextView userName;

    ArrayList<Chat> listChat = new ArrayList<Chat>();
    User user = new User();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_thread);
        setTitle("Message Threads");

        addNewThreadTitle = findViewById(R.id.editText_newThreadName);
        imageViewAddTitle = findViewById(R.id.imageView_addThreadName);
        titleList = findViewById(R.id.listView);
        logout = findViewById(R.id.imageView_logout);
        userName = findViewById(R.id.textView_userName);

        preferences = getSharedPreferences("MY_PREFERENCES", MODE_PRIVATE);
        String testToken = preferences.getString("token","");
        String userObj = preferences.getString("userObj","");
        if (!testToken.equals("") && !userObj.equals("")){

            Gson gson = new Gson();
            user = gson.fromJson(userObj,User.class);
            Log.d("demo", "onCreate: "+user.getUser_fname()+" : "+user.getUser_email());
            loggedInUserId = user.getUser_id();

            userName.setText(user.getUser_fname()+" "+user.getUser_lname());
            if (isConnected()){
                showProgress("Loading...");
                new LoadMessageThread().execute(API_GET_THREAD);
            }
        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferences.edit().remove("token").commit();
                preferences.edit().remove("userObj").commit();
                Intent intent = new Intent(MessageActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        imageViewAddTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                addNewThread(addNewThreadTitle.getText().toString());
                addNewThreadTitle.setText("");
                new LoadMessageThread().execute(API_GET_THREAD);
            }
        });

        titleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MessageActivity.this,ChatRoomActivity.class);
                Gson gson = new Gson();
                String json = gson.toJson(listChat.get(i));
                String userJson = gson.toJson(user);
                intent.putExtra("listViewJson", json);
                intent.putExtra("user",userJson);
                startActivity(intent);
            }
        });

    }

    public void showProgress(String title) {
        LinearLayout linearLayout = getLinearLayout();

        ProgressBar progress = new ProgressBar(this);
        TextView message = new TextView(this);
        message.setText(title);
        linearLayout.addView(progress);
        linearLayout.addView(message);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setCancelable(false);
        dialogBuilder.setView(linearLayout);
        progressDialog = dialogBuilder.create();
        progressDialog.show();
    }

    public LinearLayout getLinearLayout(){
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setPadding(40, 40, 40, 40);
        linearLayout.setGravity(Gravity.CENTER);

        return linearLayout;
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService( Context.CONNECTIVITY_SERVICE );
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != ConnectivityManager.TYPE_WIFI && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        } else
            return true;
    }

    class MessageThreadAdapter extends ArrayAdapter<Chat>{

        Context context;
        ArrayList<Chat> objects;


        public MessageThreadAdapter(@NonNull Context context, int resource, @NonNull List<Chat> objects) {
            super(context, resource, objects);
            this.context = context;
            this.objects = (ArrayList<Chat>) objects;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            ViewHandler viewHandler;
            if(convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.activity_chat_listview, parent, false);
                viewHandler = new ViewHandler();
                viewHandler.title = convertView.findViewById(R.id.textView_title);
                viewHandler.delete = convertView.findViewById(R.id.imageView_delete);
                convertView.setTag(viewHandler);
            }

            viewHandler = (ViewHandler) convertView.getTag();
            Chat chat = objects.get(position);
            TextView title = viewHandler.title;
            ImageView delete = viewHandler.delete;
            Log.d("demo", "getView: "+chat.getUser_id()+" "+loggedInUserId);
            title.setText(chat.title);
            delete.setVisibility(View.INVISIBLE);
            if (chat.getUser_id().toString().equals(loggedInUserId.toString())){
                delete.setVisibility(View.VISIBLE);
            }
            delete.setTag(position);
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isConnected()){
                        int i = (int) view.getTag();
                        Chat item = getItem(i);
                        Log.d("demo", "onClick: in delete"+item.getId());
                        deleteThread(API_DELETE_THREAD,item.getId());
                        new LoadMessageThread().execute(API_GET_THREAD);
                    }
                }
            });

            return convertView;
        }

        class ViewHandler{
            TextView title;
            ImageView delete;
        }
    }

    class LoadMessageThread extends AsyncTask<String, Integer, ArrayList<Chat>>{


        @Override
        protected void onPostExecute(ArrayList<Chat> chats) {
            MessageThreadAdapter mta = new MessageThreadAdapter(MessageActivity.this,R.layout.activity_message_thread,chats);
            titleList.setAdapter(mta);
            progressDialog.dismiss();
        }

        @Override
        protected ArrayList<Chat> doInBackground(String... strings) {

            listChat.clear();
            OkHttpClient client = new OkHttpClient();

            Request getAllThreads = new  Request.Builder()
                    .url(strings[0])
                    .header("Authorization","BEARER "+preferences.getString("token",""))
                    .build();

            Response response = null;
            try {

                response = client.newCall(getAllThreads).execute();
                final JSONObject root = new JSONObject(response.body().string());
                JSONArray threads = new JSONArray(root.getString("threads"));
                for (int i=0;i< threads.length();i++){
                    JSONObject json = threads.getJSONObject(i);
                    Chat chat = new Chat();
                    chat.setUser_id(json.getString("user_id"));
                    chat.setTitle(json.getString("title"));
                    chat.setId(json.getString("id"));

                    listChat.add(chat);
                }

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return listChat;
        }
    }

    private void addNewThread(String string){

        OkHttpClient client = new OkHttpClient();

        RequestBody addThreadBody = new FormBody.Builder()
                .add("title",string)
                .build();

        Request addingThread = new Request.Builder()
                .url(API_ADD_THREAD)
                .header("Authorization","BEARER "+preferences.getString("token",""))
                .post(addThreadBody)
                .build();

        client.newCall(addingThread).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                try {
                    final JSONObject root = new JSONObject(response.body().string());
                    String status = root.getString("status");
                    if (status.equals("ok")){
                        JSONArray thread = new JSONArray("threads");
                        JSONObject json = thread.getJSONObject(0);
                        Chat chat = new Chat();
                        chat.setTitle(json.getString("title"));
                        chat.setUser_id(json.getString("user_id"));
                        chat.setId(json.getString("id"));
                        chat.setUser_fname(json.getString("user_fname"));
                        chat.setUser_lname(json.getString("user_lname"));
                        chat.setCreated_at(json.getString("created_at"));
                    }
                    else{
                        MessageActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Toast.makeText(MessageActivity.this,root.getString("message"), Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void deleteThread(String string,String id){

        OkHttpClient client = new OkHttpClient();

        Request deleteThread = new Request.Builder()
                .header("Authorization","BEARER "+preferences.getString("token",""))
                .url(string+id)
                .build();
        Log.d("demo", "deleteThread: "+string+id);
        client.newCall(deleteThread).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                try {
                    final JSONObject root = new JSONObject(response.body().string());
                    String status = root.getString("status");
                    if (status.equals("ok")){
                        MessageActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MessageActivity.this, "Thread has been deleted!!", Toast.LENGTH_SHORT).show();
                            }
                        });
                        new LoadMessageThread().execute(API_GET_THREAD);
                    }
                    else{
                        MessageActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Toast.makeText(MessageActivity.this, root.getString("message"), Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
