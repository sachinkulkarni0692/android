package com.example.pabhivarshnv.chatroom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {

    AlertDialog progressDialog = null;
    private static String API_LOGIN = "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/login";
    SharedPreferences preferences=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText email = findViewById(R.id.editText_Email);
        final EditText password = findViewById(R.id.editText_password);
        final Button login = findViewById(R.id.button_login);
        Button signUp = findViewById(R.id.button_signup);

        preferences = getSharedPreferences("MY_PREFERENCES", MODE_PRIVATE);

        String testToken = preferences.getString("token","");
        String userObj = preferences.getString("userObj","");
        if (!testToken.equals("") && !userObj.equals("")){
            Gson gson = new Gson();
            User user = gson.fromJson(userObj,User.class);
            Intent intent = new Intent(LoginActivity.this, MessageActivity.class);
            //intent.putExtra("userObj",(Serializable)user);
            startActivity(intent);
            finish();
        }

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isConnected()){

                    showProgress("Loading...");
                    OkHttpClient client = new OkHttpClient();
                    RequestBody loginBody = new FormBody.Builder()
                            .add("email",email.getText().toString())
                            .add("password",password.getText().toString())
                            .build();

                    Request loginRequest = new Request.Builder()
                            .url(API_LOGIN)
                            .post(loginBody)
                            .build();

                    client.newCall(loginRequest).enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {

                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {

                            try {
                                final JSONObject root = new JSONObject(response.body().string());
                                String status = root.getString("status");
                                progressDialog.dismiss();
                                if (status.equals("ok")){
                                    User user = new User();
                                    user.setStatus(root.getString("status"));
                                    user.setToken(root.getString("token"));
                                    user.setUser_email(root.getString("user_email"));
                                    user.setUser_fname(root.getString("user_fname"));
                                    user.setUser_lname(root.getString("user_lname"));
                                    user.setUser_role(root.getString("user_role"));
                                    user.setUser_id(root.getString("user_id"));

                                    preferences.edit().remove("token").commit();
                                    preferences.edit().putString("token",user.getToken()).commit();
                                    Gson gson = new Gson();
                                    String userObj = gson.toJson(user);
                                    preferences.edit().putString("userObj",userObj).commit();

                                    Log.d("demo", "onResponse: "+user.getToken()+" : "+userObj);

                                    Intent intent = new Intent(LoginActivity.this,MessageActivity.class);
                                    //intent.putExtra("userObj", (Serializable) user);
                                    startActivity(intent);
                                    finish();
                                }
                                else {
                                    LoginActivity.this.runOnUiThread(new Runnable() {
                                        public void run() {
                                            try {
                                                Toast.makeText(LoginActivity.this, root.getString("message"), Toast.LENGTH_SHORT).show();
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });
                }
                else {
                    Toast.makeText(LoginActivity.this, "Please check you internet connection", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void showProgress(String title) {
        LinearLayout linearLayout = getLinearLayout();

        ProgressBar progress = new ProgressBar(this);
        TextView message = new TextView(this);
        message.setText(title);
        linearLayout.addView(progress);
        linearLayout.addView(message);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setCancelable(false);
        dialogBuilder.setView(linearLayout);
        progressDialog = dialogBuilder.create();
        progressDialog.show();
    }

    public LinearLayout getLinearLayout(){
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        linearLayout.setPadding(40, 40, 40, 40);
        linearLayout.setGravity(Gravity.CENTER);

        return linearLayout;
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService( Context.CONNECTIVITY_SERVICE );
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != ConnectivityManager.TYPE_WIFI && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        } else
            return true;
    }
}
