package com.example.sachi.inclass04;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static android.net.wifi.WifiConfiguration.Status.strings;

public class MainActivity extends AppCompatActivity {
    Button threadBtn;
    Button asyncBtn;
    ProgressBar pbar;
    ImageView image;
    ExecutorService threadpool;

    Handler handler = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            image = (ImageView) findViewById(R.id.imageView);
            image.setImageBitmap((Bitmap) msg.obj);
            return true;
        }

    });

    Handler progresshandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            pbar.setProgress(message.what);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(R.string.display);

        threadpool = Executors.newFixedThreadPool(4);
        threadBtn = findViewById(R.id.button);
        threadBtn.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             pbar = findViewById(R.id.progressBar);
                                             pbar.setMax(100);
                                             pbar.setProgress(0);
                                             threadpool.execute(new UseThread());
                                             //Thread thread = new Thread(new UseThread(), "thread");
                                             //thread.start();
                                         }
                                     }
        );

        asyncBtn = findViewById(R.id.button2);
        asyncBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetImageAsync().execute("https://cdn.pixabay.com/photo/2014/12/16/22/25/youth-570881_960_720.jpg");
                }
        }
        );
    }

    public class UseThread implements Runnable {

        private Handler imageHandler;

        @Override
        public void run() {
            try {
                URL imageurl = new URL("https://cdn.pixabay.com/photo/2017/12/31/06/16/boats-3051610_960_720.jpg");
                Bitmap img = BitmapFactory.decodeStream(imageurl.openStream());
                if (img != null) {
                    //Message msg = new Message();
                    for (int i = 0; i < 100; i++) {
                        for (int j = 1; j < 1000000; j++) {
                        }
                        Message msg = new Message();
                        msg.what = i;
                        progresshandler.sendMessage(msg);

                    }
                    Message message = new Message();
                    message.obj = img;
                    handler.sendMessage(message);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public class GetImageAsync extends AsyncTask<String, Integer, Bitmap> {

        ProgressBar progressBar;

        @Override
        protected void onPreExecute() {
            progressBar = findViewById(R.id.progressBar);
            progressBar.setProgress(0);
            progressBar.setMax(100);
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            HttpURLConnection connection = null;
            Bitmap bitmap = null;
            URL url = null;
            try {
                url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                for (int i = 0; i < 100; i++) {
                    for (int j = 1; j < 1000000; j++) {
                    }
                    publishProgress(i);
                }

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            progressBar.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(Bitmap Bitmap) {
            image = (ImageView) findViewById(R.id.imageView);
            image.setImageBitmap(Bitmap);
            }

    }

}