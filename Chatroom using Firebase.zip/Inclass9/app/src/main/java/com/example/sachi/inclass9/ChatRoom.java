package com.example.sachi.inclass9;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import org.ocpsoft.prettytime.PrettyTime;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ChatRoom extends AppCompatActivity {

    private static final int PERMISSION_CODE = 0;
    TextView displayName;
    ImageView sendmessage;
    EditText typeMessage;
    ImageView logout;
    ImageView uploadImage;

    Uri selectedImage;

    static ArrayList<Message> messageList = new ArrayList<>();
    Message message = new Message();

    static Map<String, Object> childUpdates = new HashMap<>();
    static ArrayList<String> keys = new ArrayList<>();
    static Map<String, Message> messageMap = new HashMap<>();

    FirebaseAuth mAuth;
    DatabaseReference database;
    FirebaseAuth firebaseAuth ;
    private FirebaseAuth.AuthStateListener  authStateListener;
    private static int RESULT_LOAD_IMG = 1;
    String imgDecodableString;
    StorageReference mStorageRef;
    ListView listView;
    static CustomListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatroom);
        displayName = findViewById(R.id.textView);
        sendmessage = findViewById(R.id.sendMessage);
        typeMessage = findViewById(R.id.typeMessage);
        logout = findViewById(R.id.logout);
        uploadImage = findViewById(R.id.uploadImage);
        listView= findViewById(R.id.messageList);

        setTitle("Chatroom");
        displayName.setText(getIntent().getStringExtra("name"));


        firebaseAuth = FirebaseAuth.getInstance();
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if(user == null){
                    startActivity(new Intent(getApplicationContext(), Login.class));
                    finish();
                }
            }
        };

        sendmessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (typeMessage.getText().length()>0){
                    Toast.makeText(getApplicationContext(),"You have pressed send message",Toast.LENGTH_LONG).show();
                    PrettyTime p = new PrettyTime();
                    try {
                        Calendar cal = Calendar.getInstance();
                        Date createdTime = cal.getTime();
                        message.setTime(p.format(createdTime));
                    } catch (Exception e) {
                        message.setTime("");
                        e.printStackTrace();
                    }
                    message.setText(typeMessage.getText().toString());
                    message.setFirstName(getIntent().getStringExtra("name").split(" ")[0]);
                    message.setLastName(getIntent().getStringExtra("name").split(" ")[1]);;
                    database = FirebaseDatabase.getInstance().getReference();
                        final String key = database.child("Message").push().getKey();
                        Map<String, Object> postValues = message.toMap();
                                childUpdates.clear();
                                childUpdates.put(key, postValues);
                                database.child("Message").updateChildren(childUpdates);
                    database.child("Message").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            Toast.makeText(getApplicationContext(),
                                    "The list has been updated", Toast.LENGTH_SHORT)
                                    .show();
                            Iterable<DataSnapshot> child = dataSnapshot.getChildren();
                            messageList.clear();
                            messageMap.clear();
                            keys.clear();
                            for (DataSnapshot c : child){
                                Message message = c.getValue(Message.class);
                                keys.add(c.getKey());
                                messageList.add(message);
                                messageMap.put(c.getKey(),message);
                            }
                            Log.d("messagelist",messageList.toString());
                            showAdapter();
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }
                    else{
                    Toast.makeText(getApplicationContext(),"Please enter message before sending",Toast.LENGTH_LONG).show();
                }
                }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                startActivity(new Intent(getApplicationContext(),Login.class));
                finish();
            }
        });

        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (ActivityCompat.checkSelfPermission(ChatRoom.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(ChatRoom.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, RESULT_LOAD_IMG);
                    } else {
                    // Create intent to Open Image applications like Gallery, Google Photos
                        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    // Start the Intent
                        startActivityForResult(galleryIntent, RESULT_LOAD_IMG);
                    }
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void showAdapter(){
        adapter = new CustomListAdapter(messageList,getApplicationContext(),getIntent().getStringExtra("name"));
        listView.setAdapter(adapter);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults)
    {
        if (requestCode == PERMISSION_CODE) {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, RESULT_LOAD_IMG);
                } else {
                    Toast.makeText(this, "Cant give permission for gallery access", Toast.LENGTH_LONG)
                            .show();
                    //do something like displaying a message that he didn`t allow the app to access gallery and you wont be able to let him select from gallery
                }
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            // When an Image is picked
            if (requestCode == RESULT_LOAD_IMG && resultCode == RESULT_OK
                    && null != data) {
                // Get the Image from data
                selectedImage = data.getData();
                String[] filePathColumn = { MediaStore.Images.Media.DATA };

                // Get the cursor
                Cursor cursor = getContentResolver().query(selectedImage,
                        filePathColumn, null, null, null);
                // Move to first row
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                imgDecodableString = cursor.getString(columnIndex);
                cursor.close();
                ImageView imgView = (ImageView) findViewById(R.id.uploadImage);
                // Set the Image in ImageView after decoding the String
                imgView.setImageBitmap(BitmapFactory
                        .decodeFile(imgDecodableString));
                uploadImage();
            }
                 else {
                    Toast.makeText(this, "You haven't picked Image",
                            Toast.LENGTH_LONG).show();
                }
        }
        catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                    .show();
        }

    }

    private void uploadImage() {

        if(selectedImage != null)
        {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();
            mStorageRef = FirebaseStorage.getInstance().getReference();
            final StorageReference ref = mStorageRef.child("images/"+ UUID.randomUUID().toString());

            UploadTask uploadTask = ref.putFile(selectedImage);

            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Toast.makeText(ChatRoom.this, "Uploaded", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(ChatRoom.this, "Failed "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot
                                    .getTotalByteCount());
                            progressDialog.setMessage("Uploaded "+(int)progress+"%");
                        }
                    });

            Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    // Continue with the task to get the download URL
                    return ref.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        message.setImage(downloadUri.toString());
                        } else {
                        message.setImage("");
                    }
                }
            });


        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        firebaseAuth.addAuthStateListener(authStateListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(authStateListener!=null){
            firebaseAuth.removeAuthStateListener(authStateListener);
        }
    }
}

