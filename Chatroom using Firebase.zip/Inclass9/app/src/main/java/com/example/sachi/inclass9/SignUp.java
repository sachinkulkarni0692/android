package com.example.sachi.inclass9;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class SignUp extends AppCompatActivity {

    private static final String TAG = " " ;
    EditText fname;
    EditText lname;
    EditText password;
    EditText Rpwd;
    EditText email;

    Button cancel;
    Button signUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        setTitle("SignUp");

        final FirebaseAuth mAuth;
        fname = findViewById(R.id.fName);
        lname = findViewById(R.id.lName);
        email = findViewById(R.id.email);
        password = findViewById(R.id.pwd);
        Rpwd = findViewById(R.id.Rpwd);

        cancel = findViewById(R.id.button_cancel);
        signUp = findViewById(R.id.button_signUp);

        mAuth = FirebaseAuth.getInstance();
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intents = new Intent(SignUp.this,Login.class);
                startActivity(intents);
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (comparePwds()) {
                    FirebaseUser currentUser = mAuth.getCurrentUser();
                    mAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                            .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    //onComplete(){
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            Log.d("success", "createUserWithEmail:success");
                                            FirebaseUser user = mAuth.getCurrentUser();
                                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                                    .setDisplayName(fname.getText().toString()+' '+lname.getText().toString())
                                                    .build();

                                            user.updateProfile(profileUpdates)
                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            if (task.isSuccessful()) {
                                                                Log.d(TAG, "User profile updated.");
                                                                Intent intent = new Intent(SignUp.this, ChatRoom.class);
                                                                intent.putExtra("name",fname.getText().toString()+' '+lname.getText().toString());
                                                                Toast.makeText(SignUp.this, "User has been created",
                                                                        Toast.LENGTH_LONG).show();
                                                                startActivity(intent);
                                                            }
                                                        }
                                                    });

                                        } else {
                                            // If sign in fails, display a message to the user.
                                            Log.w("failure", "createUserWithEmail:failure", task.getException());
                                            Toast.makeText(SignUp.this, "Authentication failed.",
                                                    Toast.LENGTH_SHORT).show();

                                        }
                                }
                            });
                }
                else{
                    Toast.makeText(SignUp.this, "Passwords do not match, Please try again.",
                            Toast.LENGTH_LONG).show();

                }
            }
        }
        );
    }

    public boolean comparePwds(){
        if(password.getText().toString().equals(Rpwd.getText().toString()) ){
            return true;
        }
        return false;
    }
}
