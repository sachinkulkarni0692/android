package com.example.sachi.inclass9;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

import static com.example.sachi.inclass9.ChatRoom.keys;


public class CustomListAdapter extends ArrayAdapter<Message>{

    // View lookup cache
    private static class ViewHolder {
        static TextView time;
        static TextView message;
        static TextView name;
        static ImageView messageImage;
        static ImageView deleteMessage;
    }

    Context context;

    String name;
    private ArrayList<Message> messageList;

    public CustomListAdapter(ArrayList<Message> messageList, Context context, String name) {
        super(context, R.layout.customlayout, messageList);
        // TODO Auto-generated constructor stub
        this.context=context;
        this.messageList=messageList;
        this.name = name;
    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Message dataModel = getItem(position);
        ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.customlayout, parent, false);

            viewHolder.message = (TextView) convertView.findViewById(R.id.message);
            viewHolder.name = (TextView) convertView.findViewById(R.id.name);
            ViewHolder.time = (TextView) convertView.findViewById(R.id.time);
            ViewHolder.messageImage = (ImageView) convertView.findViewById(R.id.messageImage);
            ViewHolder.deleteMessage = (ImageView) convertView.findViewById(R.id.imageView_delete);
            ViewHolder.deleteMessage.setTag(position);
            result = convertView;
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }

        lastPosition = position;

        viewHolder.name.setText(dataModel.getFirstName());
        viewHolder.message.setText(dataModel.getText());
        viewHolder.time.setText(dataModel.getTime());
        if (dataModel.getImage()!=null){
            Picasso.get()
                    .load(dataModel.getImage())
                    .into(ViewHolder.messageImage);
        }
        else{
            viewHolder.messageImage.setVisibility(View.INVISIBLE);
        }
        Drawable imgDrawable=CustomListAdapter.this.context.getDrawable(R.drawable.delete);
        viewHolder.deleteMessage.setImageDrawable(imgDrawable);
        if (!(name.split(" ")[0].equals(dataModel.getFirstName()) && name.split(" ")[1].equals(dataModel.getLastName()))){
            viewHolder.deleteMessage.setVisibility(View.INVISIBLE);
        }

        viewHolder.deleteMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = (int) v.getTag();
                Message item = messageList.get(i);
                DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                database.child("Message").child(keys.get(i)).removeValue();
                keys.remove(keys.get(i));
            }
        });
        return convertView;
    }
}