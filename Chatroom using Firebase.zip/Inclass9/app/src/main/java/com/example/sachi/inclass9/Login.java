package com.example.sachi.inclass9;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity {
    Button login;
    Button signUp;
    EditText email;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        setTitle("Login");
        final FirebaseAuth mAuth;
        mAuth = FirebaseAuth.getInstance();
        login = findViewById(R.id.button2);
        signUp = findViewById(R.id.button);
        email = findViewById(R.id.editText);
        password = findViewById(R.id.editText2);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mAuth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("success", "signInWithEmail:success");
                                    Toast.makeText(Login.this, "Authentication Sucess.",
                                            Toast.LENGTH_LONG).show();
                                    FirebaseUser user = mAuth.getInstance().getCurrentUser();
                                    if(user!=null) {
                                        Log.d("display", user.getDisplayName());
                                        Intent intent = new Intent(Login.this, ChatRoom.class);
                                        intent.putExtra("name",user.getDisplayName());
                                        //DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                                        //intent.putExtra("database", (Parcelable) database);
                                        startActivity(intent);
                                    }
                                    else{
                                        Toast.makeText(Login.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w("failure", "signInWithEmail:failure", task.getException());
                                    Toast.makeText(Login.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                    //updateUI(null);
                                }

                                // ...
                            }
                        });
            }
        }
        );

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intents = new Intent(Login.this,SignUp.class);
                startActivity(intents);
            }
        });
    }
}
