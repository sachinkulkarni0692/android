package com.example.finalexam.utils;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.database.Exclude;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mshehab on 5/6/18.
 */

public class Person implements Serializable {
    String name;
    int totalBudget;
    int totalBought;
    int giftCount;
    ArrayList<Gift> gifts;
    int remaining;

    String id;

    public Person() {
        this.totalBought = 0;
        this.giftCount = 0;
    }

    public int getRemaining() {
        return remaining;
    }

    public void setRemaining(int remaining) {
        this.remaining = remaining;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalBudget() {
        return totalBudget;
    }

    public void setTotalBudget(int totalBudget) {
        this.totalBudget = totalBudget;
    }

    public int getTotalBought() {
        return totalBought;
    }

    public void setTotalBought(int totalBought) {
        this.totalBought = totalBought;
    }

    public int getGiftCount() {
        return giftCount;
    }

    public void setGiftCount(int giftCount) {
        this.giftCount = giftCount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public ArrayList<Gift> getGifts() {
        return gifts;
    }

    public void setGifts(ArrayList<Gift> gifts) {
        this.gifts = gifts;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", totalBudget=" + totalBudget +
                ", totalBought=" + totalBought +
                ", giftCount=" + giftCount +
                ", id='" + id + '\'' +
                '}';
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("name", name);
        result.put("totalBudget",totalBudget);
        result.put("totalBought",totalBought);
        result.put("giftCount",giftCount);
        result.put("id",id);
        result.put("remaining",remaining);
        result.put("gifts",gifts);
        return result;
    }
}
