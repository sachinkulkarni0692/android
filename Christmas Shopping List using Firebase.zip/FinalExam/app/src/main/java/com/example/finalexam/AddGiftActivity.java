package com.example.finalexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.finalexam.utils.Gift;
import com.example.finalexam.utils.GiftsAdapter;
import com.example.finalexam.utils.Person;
import com.example.finalexam.utils.PersonsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static com.example.finalexam.ChristmasListActivity.personMap;

public class AddGiftActivity extends AppCompatActivity {
    final String TAG = "demo";
    ListView listView;
    GiftsAdapter giftsAdapter;
    ArrayList<Gift> gifts = new ArrayList<>();
    static ArrayList<Gift> selectedgifts = new ArrayList<>();
    DatabaseReference database;
    Person person;
    int remaining;
    int totalBudget;

    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_gift);
        setTitle(R.string.add_gift);
        intent = new Intent(AddGiftActivity.this,PersonGiftsActivity.class);
        person = (Person) getIntent().getSerializableExtra("Person");
        totalBudget = person.getTotalBudget();
        remaining = person.getRemaining();
        Log.d("initial remainig",String.valueOf(remaining));
        listView = findViewById(R.id.listview);
        database = FirebaseDatabase.getInstance().getReference();

        database.child("gifts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Toast.makeText(getApplicationContext(),
                        "The list has been updated", Toast.LENGTH_SHORT)
                        .show();
                Iterable<DataSnapshot> child = dataSnapshot.getChildren();
                for (DataSnapshot c : child){
                    Gift gift = c.getValue(Gift.class);
                    gifts.add(gift);
                }
                ArrayList<Gift> giftlist = new ArrayList<Gift>(gifts);
                intent.putExtra("giftItems",giftlist);
                showAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                int i = position;
                Gift gift = gifts.get(i);
                int giftPrice = gift.getPrice();
                remaining -= giftPrice;
                person.setGiftCount(person.getGiftCount()+1);
                person.setTotalBought(person.getTotalBought()+1);
                person.setRemaining(remaining);
                selectedgifts.add(gift);
                person.setGifts(selectedgifts);
                String id="";
                for(Map.Entry<String,Person> entry :personMap.entrySet()){
                    if (entry.getValue().getName().equalsIgnoreCase(person.getName())){
                        id = entry.getKey();
                    }
                };
                database = FirebaseDatabase.getInstance().getReference();
                database.child("Persons").child(id).child("giftCount").setValue(person.getGiftCount());
                database.child("Persons").child(id).child("totalBought").setValue(person.getGiftCount());
                database.child("Persons").child(id).child("remaining").setValue(person.getRemaining());
                database.child("Persons").child(id).child("gift").setValue(person.getGifts());
                Log.d("remaining amt",String.valueOf(remaining));
                for (Iterator<Gift> it = gifts.iterator(); it.hasNext(); ) {
                    Gift g = it.next();
                    if (g.getPrice()>remaining) {
                        it.remove();
                        if(gifts.size()==0){
                            //intent.putExtra("selectedgifts", selectedgifts);
                            Toast.makeText(getApplicationContext(),selectedgifts.toString(),Toast.LENGTH_LONG).show();
                            person.setGifts(selectedgifts);
                            intent.putExtra("Person",person);
                            startActivity(intent);
                        }
                        showAdapter();
                    }
                }

            }
        });
    }

    public void showAdapter(){
        giftsAdapter = new GiftsAdapter(this, R.layout.gift_item, gifts);
        listView.setAdapter(giftsAdapter);
    }
}
