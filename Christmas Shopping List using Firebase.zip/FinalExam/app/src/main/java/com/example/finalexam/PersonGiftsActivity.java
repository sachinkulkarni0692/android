package com.example.finalexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.example.finalexam.utils.Gift;
import com.example.finalexam.utils.GiftsAdapter;
import com.example.finalexam.utils.Person;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;

import static com.example.finalexam.AddGiftActivity.selectedgifts;
import static com.example.finalexam.ChristmasListActivity.personMap;

public class PersonGiftsActivity extends AppCompatActivity {
    final String TAG = "demo";
    ListView listView;
    GiftsAdapter giftsAdapter;
    ArrayList<Gift> selectedgifts =new ArrayList<>();
    ArrayList<Gift> giftItems =  new ArrayList<Gift>();
    DatabaseReference database;
    Person person;
    int remaining;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_gifts);

        person = (Person) getIntent().getSerializableExtra("Person");
        //giftItems  //(ArrayList<Gift>) getIntent().getSerializableExtra("giftItems");
        Log.d("here","here");
        //selectedgifts =person.getGifts();//(ArrayList<Gift>) getIntent().getSerializableExtra("selectedgifts");
        //if (selectedgifts == null){
         //   selectedgifts = new ArrayList<Gift>();
          //  remaining = 0;
        //}
        //if(giftItems == null){
         //   giftItems = new ArrayList<Gift>();
        //}

        remaining = person.getRemaining();
        setTitle(person.getName());
        listView = findViewById(R.id.listview);
        database = FirebaseDatabase.getInstance().getReference();
        String id="";
        for(Map.Entry<String,Person> entry :personMap.entrySet()){
            if (entry.getValue().getName().equalsIgnoreCase(person.getName())){
                id = entry.getKey();
            }
        }

        database.child("Persons").child(id).child("gift").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Toast.makeText(getApplicationContext(),
                        "The list has been updated", Toast.LENGTH_SHORT)
                        .show();
                Iterable<DataSnapshot> child = dataSnapshot.getChildren();
                for (DataSnapshot c : child){
                    Gift gift = c.getValue(Gift.class);
                    selectedgifts.add(gift);
                }
                showAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        }
        );

        database.child("Persons").child(id).child("remaining").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
               Log.d("here","here");
                Iterable<DataSnapshot> child = dataSnapshot.getChildren();
                for (DataSnapshot c : child){
                    remaining = (int) c.getValue();
                    //selectedgifts.add(gift);
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    }
                }
        );

        database.child("gifts").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Toast.makeText(getApplicationContext(),
                        "The list has been updated", Toast.LENGTH_SHORT)
                        .show();
                Iterable<DataSnapshot> child = dataSnapshot.getChildren();
                for (DataSnapshot c : child){
                    Gift gift = c.getValue(Gift.class);
                    giftItems.add(gift);
                }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            }
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.person_gifts_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.add_gift_menu_item:
                Log.d(TAG, "onOptionsItemSelected: ");
                Log.d("remaining",String.valueOf(remaining));
                int min=0;
                if (giftItems!=null){
                    Log.d("giftItems",giftItems.toString());
                }
                if(giftItems.size()>0){
                    min = giftItems.get(0).getPrice();
                    for(Gift g  : giftItems){
                        min = min < g.getPrice() ? min : g.getPrice();
                    }
                }
                if (remaining>min){
                    Intent intent = new Intent(this, AddGiftActivity.class);
                    intent.putExtra("Person",person);
                    startActivity(intent);
                    return true;
                }
                else{
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),"Person budget exceeded!!",Toast.LENGTH_LONG).show();
                        }
                    });
                }
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public void showAdapter(){
        giftsAdapter = new GiftsAdapter(this, R.layout.gift_item, selectedgifts);
        listView.setAdapter(giftsAdapter);
    }}
