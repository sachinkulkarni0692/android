package com.example.sachi.inclass08;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.ocpsoft.prettytime.PrettyTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{//},CustomListAdapter.UpdateCheckBox{

    static HashMap<Integer,Boolean> checkMap = new HashMap<>();
    static ArrayList<Integer> checkedArray = new ArrayList<Integer>();
    EditText editData;
    Button addButton;
    Spinner spinner;
    static ListView listView;
    static CustomListAdapter adapter;
    static ArrayList<Task> taskList = new ArrayList<>();
    Task task = new Task();
    static Map<String, Object> childUpdates = new HashMap<>();
    //static Context context = getApplicationContext();
    static ArrayList<String> keys = new ArrayList<>();
    static Map<String, Task> taskMap = new HashMap<>();

    DatabaseReference database = FirebaseDatabase.getInstance().getReference();
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("TODO List");

        editData = findViewById(R.id.editData);
        addButton =  findViewById(R.id.addButton);
        spinner =  findViewById(R.id.prioritySpinner);
        listView = findViewById(R.id.newsArticleList);
        //spinner.setPrompt("Priority");

        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayList<String> categories = new ArrayList<>();
        //categories.add("Priority");
        categories.add("High");
        categories.add("Medium");
        categories.add("Low");

        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        spinner.setAdapter(dataAdapter);


        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editData.getText().length()>0) {
                    task.setTitle(editData.getText().toString());
                    task.setStatus("pending");
                    PrettyTime p = new PrettyTime();
                    try {
                        Calendar cal = Calendar.getInstance();
                        Date createdTime = cal.getTime();
                        task.setTime(p.format(createdTime));
                    } catch (Exception e) {
                        task.setTime("");
                        e.printStackTrace();
                    }

                    final String key = database.child("task").push().getKey();
                    Map<String, Object> postValues = task.toMap();
                    childUpdates.clear();
                    childUpdates.put(key, postValues);
                    //keys.add(key);
                }
                    database.child("task").updateChildren(childUpdates);
                    database.child("task").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            Toast.makeText(getApplicationContext(),
                                    "The list has been updated", Toast.LENGTH_SHORT)
                                    .show();
                            Iterable<DataSnapshot> child = dataSnapshot.getChildren();
                            taskList.clear();
                            taskMap.clear();
                            keys.clear();
                            for (DataSnapshot c : child){
                                Task task = c.getValue(Task.class);
                                keys.add(c.getKey());
                                taskList.add(task);
                                taskMap.put(c.getKey(),task);
                            }
                            showAdapter();
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }
            //}
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int pos, long id) {
                // TODO Auto-generated method stub

                final DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                final int i = pos;
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                                MainActivity.this);

                        alertDialog2.setTitle("Confirm Delete...");

                        alertDialog2.setMessage("Are you sure you want delete this Task?");

                        alertDialog2.setPositiveButton("YES",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // Write your code here to execute after dialog
                                        final List<String> keyList = new ArrayList<String>(childUpdates.keySet());
                                        database.child("task").child(keys.get(i)).removeValue();
                                        keys.remove(keys.get(i));
                                        dialog.cancel();
                                    }
                                });
                        alertDialog2.setNegativeButton("NO",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                });
                        alertDialog2.show();
                        }
                });
                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Toast.makeText(getApplicationContext(),"Select All",Toast.LENGTH_LONG).show();
                showAdapter();
                return true;
            case R.id.item2:
                Toast.makeText(getApplicationContext(),"Show Completed",Toast.LENGTH_LONG).show();
                ArrayList<Task> completedtasks = new ArrayList<>();
                for (Task t: taskList){
                    if (t.getStatus().equals("completed")){
                        completedtasks.add(t);
                    }
                    if (completedtasks.size()>0){
                        adapter = new CustomListAdapter(completedtasks,getApplicationContext());
                        listView.setAdapter(adapter);
                    }
                }
                return true;
            case R.id.item3:
                Toast.makeText(getApplicationContext(),"Show Pending",Toast.LENGTH_LONG).show();
                ArrayList<Task> pendingtasks = new ArrayList<>();
                for (Task t: taskList){
                    if (t.getStatus().equals("pending")){
                        pendingtasks.add(t);
                    }
                    if (pendingtasks.size()>0){
                        adapter = new CustomListAdapter(pendingtasks,getApplicationContext());
                        listView.setAdapter(adapter);
                    }
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void showAdapter(){
        adapter = new CustomListAdapter(taskList,getApplicationContext());
        listView.setAdapter(adapter);
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        task.setPriority(item);
    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }
}
