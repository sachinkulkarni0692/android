package com.example.sachi.inclass08;


import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.ocpsoft.prettytime.PrettyTime;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.example.sachi.inclass08.MainActivity.checkMap;
import static com.example.sachi.inclass08.MainActivity.checkedArray;
import static com.example.sachi.inclass08.MainActivity.childUpdates;
import static com.example.sachi.inclass08.MainActivity.keys;
import static com.example.sachi.inclass08.MainActivity.taskMap;

public class CustomListAdapter extends ArrayAdapter<Task> implements CompoundButton.OnCheckedChangeListener{
   SparseBooleanArray mCheckStates;

    // View lookup cache
    private static class ViewHolder {
        static TextView time;
        static TextView articleTitle;
        static TextView articleAuthor;
        static CheckBox checkbox;
    }

    Context context;

    private ArrayList<Task> articleList;

    public CustomListAdapter(ArrayList<Task> articleList,Context context) {
        super(context, R.layout.customlayout, articleList);
        // TODO Auto-generated constructor stub
        this.context=context;
        this.articleList=articleList;
        mCheckStates = new SparseBooleanArray(articleList.size());
    }

    private int lastPosition = -1;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Task dataModel = getItem(position);
        ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.customlayout, parent, false);

            viewHolder.articleTitle = (TextView) convertView.findViewById(R.id.articleTitle);
            viewHolder.articleAuthor = (TextView) convertView.findViewById(R.id.articleAuthor);
            viewHolder.checkbox = (CheckBox) convertView.findViewById(R.id.checkBox2);
            ViewHolder.time = (TextView) convertView.findViewById(R.id.time);

            result=convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        lastPosition = position;

        viewHolder.articleTitle.setText(dataModel.getTitle());
        viewHolder.articleAuthor.setText(dataModel.getPriority());
        viewHolder.checkbox.setTag(position);
        viewHolder.time.setText(dataModel.getTime());

        //if (checkMap.size()>0 && checkMap.get(position)!=null){
          if  (dataModel.getStatus().equals("completed")){
            viewHolder.checkbox.setChecked(mCheckStates.get(position, true));
        }
        else{
            viewHolder.checkbox.setChecked(mCheckStates.get(position, false));
        }

        viewHolder.checkbox.setOnCheckedChangeListener(this);
        return convertView;
    }


    public boolean isChecked(int position) {
        return mCheckStates.get(position, false);
    }

    public void setChecked(int position, boolean isChecked) {
        mCheckStates.put(position, isChecked);
    }

    public void toggle(int position) {
        setChecked(position, !isChecked(position));

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView,
                                 boolean isChecked) {

        mCheckStates.put((Integer) buttonView.getTag(), isChecked);
        Log.d("selected item",String.valueOf((Integer) buttonView.getTag()));
        if (checkedArray.contains((Integer) buttonView.getTag())){
            checkedArray.remove((Integer) buttonView.getTag());
        }
        else{
            checkedArray.add((Integer) buttonView.getTag());
        }
        checkMap.put((Integer) buttonView.getTag(),true);

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        List<String> keyList = new ArrayList<String>(childUpdates.keySet());
        if (checkedArray.size()>0) {
            for (Integer i : checkedArray) {
                Log.d("the value of i ",String.valueOf(i));
                Task task = taskMap.get(keys.get(i));
                //Task t = Task.toObject((Map<String, Object>) task);
                task.setStatus("completed");
                Map<String, Object> postValues = task.toMap();
                taskMap.remove(keys.get(i));
                childUpdates.put(keys.get(i), postValues);
            }
            database.child("task").updateChildren(childUpdates);
        }
    }

}